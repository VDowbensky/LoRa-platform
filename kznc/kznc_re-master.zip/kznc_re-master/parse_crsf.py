#!/usr/bin/env python3

import argparse
import json
from pathlib import Path
from typing import List, Dict, Any, Optional

# ---- CRSF constants ----
TYPE_NAMES = {
    0x14: "LinkStatistics",
    0x16: "RcChannelsPacked",
    0x02: "DeviceInfo",
    0x08: "GPS",
    0x1E: "Attitude",
    0x21: "BatterySensor",
    0x29: "DevicePing",
}


def crc8(data: bytes, poly: int = 0xD5, init: int = 0x00) -> int:
    crc = init
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) ^ poly) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
    return crc


def parse_rc_channels(payload: bytes, map_to_us: bool = False) -> Dict[str, Any]:
    """
    payload (22 bytes) encodes 16 channels, 11 bits each, little-endian packed.
    Returns raw list [0..2047] and, if requested, microseconds mapped to ~1000..2000 us.
    CRSF standard range: 172..1811, center 992.
    """
    out: Dict[str, Any] = {}
    if len(payload) != 22:
        out["error"] = f"unexpected payload length: {len(payload)} (expected 22)"
        return out
    val = int.from_bytes(payload, "little")
    raws = [(val >> (i * 11)) & 0x7FF for i in range(16)]
    out["raw"] = raws

    if map_to_us:
        def to_us(v: int) -> float:
            # 172..1811 maps to 1000..2000 us; 992 is center (1500us)
            return 1500.0 + (v - 992) * 500.0 / 820.0

        out["us"] = [round(to_us(v), 1) for v in raws]
    return out


def parse_link_stats(payload: bytes) -> Dict[str, Any]:
    """
    CRSF Link Statistics (10 bytes):
    int8  uplink_rssi1, int8 uplink_rssi2, uint8 uplink_lq,
    int8  uplink_snr,   uint8 rf_mode,     uint8 uplink_tx_power,
    int8  downlink_rssi,uint8 downlink_lq, int8  downlink_snr,
    uint8 active_antenna
    """

    def s8(b: int) -> int:
        return b - 256 if b > 127 else b

    if len(payload) != 10:
        return {"error": f"unexpected payload length: {len(payload)} (expected 10)"}
    u = list(payload)
    return {
        "uplink_rssi1_dbm": s8(u[0]),
        "uplink_rssi2_dbm": s8(u[1]),
        "uplink_lq_percent": u[2],
        "uplink_snr_db": s8(u[3]),
        "rf_mode": u[4],
        "uplink_tx_power": u[5],
        "downlink_rssi_dbm": s8(u[6]),
        "downlink_lq_percent": u[7],
        "downlink_snr_db": s8(u[8]),
        "active_antenna": u[9],
    }


def parse_frames(data: bytes, map_us: bool = False) -> List[Dict[str, Any]]:
    frames = []
    i = 0
    n = len(data)
    while i + 3 < n:
        addr = data[i]
        length = data[i + 1]
        # length counts (Type + Payload + CRC), but CRC is *after* those length bytes.
        # So the frame boundary (excluding addr/len) is i+2..i+1+length; and crc is at i+1+length.
        if length == 0 or i + 2 + length >= n:
            # incomplete or malformed tail
            break
        frame_bytes = data[i + 2:i + 1 + length]  # includes type + payload
        ftype = frame_bytes[0]
        payload = frame_bytes[1:]
        crc = data[i + 1 + length]
        crc_ok = (crc8(frame_bytes) == crc)

        tname = TYPE_NAMES.get(ftype, f"0x{ftype:02X}")
        decoded: Optional[Dict[str, Any]] = None
        if ftype == 0x16:
            decoded = parse_rc_channels(payload, map_us)
        elif ftype == 0x14:
            decoded = parse_link_stats(payload)

        frames.append({
            "offset": i,
            "addr": f"0x{addr:02X}",
            "length": length,
            "type": f"0x{ftype:02X}",
            "type_name": tname,
            "payload_len": len(payload),
            "crc": f"0x{crc:02X}",
            "crc_ok": crc_ok,
            "payload_hex": payload.hex(" "),
            "decoded": decoded,
        })
        i += length + 2
    return frames


def format_table(frames: List[Dict[str, Any]], show_all_channels: bool = False) -> str:
    lines = []
    header = ["offset", "addr", "len", "type", "crc_ok"]
    if show_all_channels:
        ch_cols = [f"ch{c + 1}" for c in range(16)]
    else:
        ch_cols = [f"ch{c + 1}" for c in range(8)]
    ls_cols = ["uplink_rssi1_dbm", "uplink_rssi2_dbm", "uplink_lq_percent", "uplink_snr_db",
               "rf_mode", "uplink_tx_power", "downlink_rssi_dbm", "downlink_lq_percent", "downlink_snr_db",
               "active_antenna"]

    # Collect rows
    rows = []
    for f in frames:
        row = {
            "offset": f["offset"], "addr": f["addr"], "len": f["length"],
            "type": f["type_name"], "crc_ok": "✔" if f["crc_ok"] else "✘"
        }
        if f["type_name"] == "RcChannelsPacked" and isinstance(f.get("decoded"), dict) and "raw" in f["decoded"]:
            raws = f["decoded"]["raw"]
            for idx, col in enumerate(ch_cols):
                row[col] = raws[idx] if idx < len(raws) else ""
        elif f["type_name"] == "LinkStatistics" and isinstance(f.get("decoded"), dict):
            for col in ls_cols:
                row[col] = f["decoded"].get(col, "")
        rows.append(row)

    # Build column order
    cols = header + ch_cols + ls_cols
    # Determine column widths
    colw = {c: max(len(c), *(len(str(r.get(c, ""))) for r in rows)) for c in cols}

    # Header
    lines.append(" ".join(f"{c:{colw[c]}}" for c in cols))
    lines.append(" ".join("-" * colw[c] for c in cols))
    # Rows
    for r in rows:
        lines.append(" ".join(f"{str(r.get(c, '')):{colw[c]}}" for c in cols))
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(
        description="Parse CRSF frames from a binary file and print a table or JSON."
    )
    ap.add_argument("file", help="Path to binary file containing CRSF frames")
    ap.add_argument("--json", dest="json_out", help="Write detailed JSON to this path")
    ap.add_argument("--format", choices=["table", "json"], default="table",
                    help="Output format to stdout (default: table)")
    ap.add_argument("--show-all-channels", action="store_true",
                    help="Show all 16 RC channels in the table (default shows first 8)")
    ap.add_argument("--map-us", action="store_true",
                    help="Also compute microsecond mapping for RC channels (included in JSON only)")
    args = ap.parse_args()

    data = Path(args.file).read_bytes()
    frames = parse_frames(data, map_us=args.map_us)

    if args.json_out:
        Path(args.json_out).write_text(json.dumps({"frames": frames}, indent=2))
        print(f"Wrote JSON: {args.json_out}")

    if args.format == "json":
        print(json.dumps({"frames": frames}, indent=2))
    else:
        print(format_table(frames, show_all_channels=args.show_all_channels))


if __name__ == "__main__":
    main()
