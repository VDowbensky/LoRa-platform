import math
from typing import Dict, Any

try:
    from rich import print as pprint
except Exception:
    def pprint(*args, **kwargs):
        print(*args, **kwargs)


def calculate_lora_params(
        *,
        payload_len: int,
        preamble_len: int,
        spreading_factor: int,
        bandwidth_khz: float,
        coding_rate: int,
        crc: bool = False,
        explicit_header: bool = True,
        low_data_rate_opt: bool = False,
        inter_packet_gap_ms: float = 0.0,  # fixed gap between packets, if any
        decimals: int = 3,
) -> Dict[str, Any]:
    """
    Compute LoRa timing/throughput parameters (Semtech formula) + packet rate.

    Returns keys:
      valid, issues, symbol_time_ms, symbol_rate_sps, n_preamble, t_preamble_ms,
      n_payload, t_payload_ms, t_total_ms, throughput_bps,
      packet_rate_per_s, packet_rate_max_per_s
    """
    issues = []

    # Normalize coding rate to CR in 1..4
    if 5 <= coding_rate <= 8:
        CR = coding_rate - 4
    elif 1 <= coding_rate <= 4:
        CR = coding_rate
    else:
        issues.append("coding_rate must be 1..4 or 5..8 (for 4/5..4/8).")
        CR = 1

    PL = int(payload_len)
    PRE = int(preamble_len)
    SF = int(spreading_factor)
    BWkHz = float(bandwidth_khz)

    CRC = 1 if crc else 0
    IH = 0 if explicit_header else 1
    DE = 1 if low_data_rate_opt else 0

    if not (1 <= PL <= 255):
        issues.append("payload_len must be 1..255.")
    if not (6 <= PRE <= 65535):
        issues.append("preamble_len must be 6..65535.")
    if not (5 <= SF <= 12):
        issues.append("spreading_factor should be 5..12.")
    if not (BWkHz > 0):
        issues.append("bandwidth_khz must be > 0.")

    # Symbol time (ms) given BW in kHz
    symbol_time_ms = (2 ** SF) / BWkHz
    symbol_rate_sps = 1000.0 / symbol_time_ms

    # Preamble timing
    n_preamble = PRE + 4.25
    t_preamble_ms = n_preamble * symbol_time_ms

    # Payload symbols (Semtech formula)
    num = 8 * PL - 4 * SF + 28 + 16 * CRC - 20 * IH
    den = 4 * (SF - 2 * DE)
    inner = max(math.ceil(num / den), 0) if den > 0 else 0
    n_payload = 8 + inner * (CR + 4)

    t_payload_ms = n_payload * symbol_time_ms
    t_total_ms = t_preamble_ms + t_payload_ms

    # Throughput (bps) = payload bits / total time (s)
    throughput_bps = (8.0 * PL) / (t_total_ms / 1000.0) if t_total_ms > 0 else 0.0

    # Packet rate: allow an optional fixed inter-packet gap
    effective_packet_ms = t_total_ms + max(inter_packet_gap_ms, 0.0)
    packet_rate_per_s = 1000.0 / effective_packet_ms if effective_packet_ms > 0 else 0.0
    packet_rate_max_per_s = int(math.floor(packet_rate_per_s + 1e-12))  # guard FP edge cases

    r = lambda x: round(x, decimals)

    return {
        "valid": len(issues) == 0,
        # "issues": issues,
        "symbol_time_ms": r(symbol_time_ms),
        "symbol_rate_sps": r(symbol_rate_sps),
        "n_preamble": r(n_preamble),
        "t_preamble_ms": r(t_preamble_ms),
        "n_payload": int(n_payload),
        "t_payload_ms": r(t_payload_ms),
        "t_total_ms": r(t_total_ms),
        "throughput_bps": r(throughput_bps),
        "packet_rate_per_s": r(packet_rate_per_s),
        "packet_rate_max_per_s": packet_rate_max_per_s,
    }


# Example:
if __name__ == "__main__":
    res = calculate_lora_params(
        payload_len=9,
        preamble_len=8,
        spreading_factor=7,
        bandwidth_khz=62.5,  # 62.5 kHz
        coding_rate=8,  # 4/5
        crc=False,
        explicit_header=False,
        low_data_rate_opt=False,
    )
    pprint(res)

    res = calculate_lora_params(
        payload_len=9,
        preamble_len=10,
        spreading_factor=7,
        bandwidth_khz=125,  # 125 kHz
        coding_rate=6,  # 4/5
        crc=False,
        explicit_header=False,
        low_data_rate_opt=False,
    )
    pprint(res)
