import argparse
import hashlib

from encryption_keys import encryption_keys
from parse_config import read_config

PARTITIONS = {
    "bootloader": (0, 0x4000),
    "firmware": (0x4000, 0x10000),
    "config": (0x10000, 0x10040),
}

VERSIONS = {
    "bootloader": {
        "e968756dac769b549b912dceab7ebef38f83deb8e0651b498ae48dada2e9372f": "v1",
    },
    "firmware": {
        "59278454cf278c657ba6b9cc2c8f72660793df5d37d0cfabda746a7f5dfe46c9": "v1 ?",
        "245ef9dc729214584f39598064e91d37994378deec3bf68a05e123ab2a973c11": "v2 ?",
        "8d216c55aa15f2a173d9bd106e23202000c888716f6581f3a835dc46372f3c99": "v3 ?",

        "7df382fb0bcae2bf29b15c17990eef59923132215dca840e35d374e6efd9035e": "2.5.1",
    },
    "config": {
    },
}


def checksum(data: bytes, start: int, end: int) -> str:
    return hashlib.sha256(data[start:end]).hexdigest()


def get_checksums(data: bytes) -> dict:
    """
    Calculate checksums for bootloader, firmware, and config sections.
    Returns a dictionary with section names as keys and their checksums as values.
    """
    checksums = {}
    for name, (start, end) in PARTITIONS.items():
        if start < len(data):
            end = min(end, len(data))  # Ensure we don't go out of bounds
            checksums[name] = checksum(data, start, end)
        else:
            checksums[name] = None  # Not enough data for this section
    return checksums


def get_versions(checksums: dict) -> dict:
    """
    Get version information based on checksums.
    Returns a dictionary with section names as keys and their checksums as values.
    """
    versions = {k: "Not available" for k in PARTITIONS.keys()}
    for section, checksum_value in checksums.items():
        versions[section] = VERSIONS.get(section, {}).get(checksum_value, "Unknown")
    return versions


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description="Analyze firmware dumps for version information.")
    ap.add_argument("dump_file", type=str, help="Path to the firmware dump file")
    args = ap.parse_args()
    dump_file = args.dump_file
    try:
        with open(dump_file, 'rb') as f:
            data = f.read()
    except FileNotFoundError:
        print(f"Error: File '{dump_file}' not found.")
        exit(1)

    config = read_config(dump_file)
    encryption_key = config["encryption_key_hex"]
    print("Encryption Key:", encryption_key)
    notes = encryption_keys.get(encryption_key)
    if notes:
        print("Notes:", notes)

    checksums = get_checksums(data)
    versions = get_versions(checksums)
    print("Checksums:")
    for section, cs in checksums.items():
        print(f" - {section}: {cs if cs else 'Not enough data'}")
    print("Versions:")
    for section, version in versions.items():
        print(f" - {section}: {version}")
