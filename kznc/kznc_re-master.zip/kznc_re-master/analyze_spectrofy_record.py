#!/usr/bin/env python3
import os
import re
import argparse
import json
from pathlib import Path
from datetime import datetime
from typing import Any, Iterable, Optional

COLORS = [
    "\033[91m",  # red
    "\033[92m",  # green
    "\033[93m",  # yellow
    "\033[94m",  # blue
    "\033[95m",  # magenta
    "\033[96m",  # cyan
]
RESET = "\033[0m"

# ---------- Helpers ----------

def try_iso8601_to_seconds(v: str) -> Optional[float]:
    try:
        # Accept "2025-09-27T01:23:45.678Z" or no 'Z'
        if v.endswith("Z"):
            v = v[:-1]
        return datetime.fromisoformat(v).timestamp()
    except Exception:
        return None


def normalize_ts(ts_val: Any, ts_unit: Optional[str]) -> Optional[float]:
    """
    Return seconds (float) or None if not parseable.
    ts_val can be:
      - number (assumed seconds/ms/us/ns depending on ts_unit or heuristics)
      - ISO8601 string
    """
    if ts_val is None:
        return None

    # strings: try ISO8601
    if isinstance(ts_val, str):
        sec = try_iso8601_to_seconds(ts_val)
        return sec

    # numeric: apply units or heuristic
    if isinstance(ts_val, (int, float)):
        if ts_unit:
            factor = {"s": 1.0, "ms": 1e-3, "us": 1e-6, "ns": 1e-9}[ts_unit]
            return ts_val * factor
        # Heuristic if not specified
        v = float(ts_val)
        if v > 1e12:  # ns
            return v * 1e-9
        if v > 1e9:  # ms/us/ns overlap; prefer us/ns guarded above; assume ms if ~UNIXms
            # If ~2025 * 1e3 ≈ 1.7e12 for ms, so >1e9 is more likely seconds w/ big int.
            # Use ranges:
            if v > 1e14:  # definitely ns
                return v * 1e-9
            if v > 1e12:  # ms
                return v * 1e-3
            # 1e9..1e12: ambiguous; assume seconds if looks like UNIX seconds
            return v
        if v > 1e6:  # likely ms
            return v * 1e-3
        # looks like seconds
        return v

    return None


def find_first_key(d: dict, keys: Iterable[str]) -> Optional[str]:
    for k in keys:
        if k in d:
            return k
    return None


def fmt_freq(f_hz: float, unit: str, rounding: Optional[int]) -> str:
    if unit == "hz":
        val = f_hz
    elif unit == "khz":
        val = f_hz / 1e3
    elif unit == "mhz":
        val = f_hz / 1e6
    else:
        val = f_hz
    return str(round(val, rounding)) if rounding is not None else str(val)


def fmt_num(v: Optional[float], rounding: Optional[int]) -> str:
    if v is None:
        return "NA"
    return str(round(v, rounding)) if rounding is not None else str(v)


# ---------- Core ----------

def load_msgs(path: Path) -> list[dict]:
    d = json.loads(path.read_text(encoding="utf-8"))
    return (d.get("msgs", []) or [])

def build_prefix_trie(strings: list[str]) -> dict:
    root = {}
    for s in strings:
        node = root
        for ch in s:
            node = node.setdefault(ch, {"_count": 0})
            node["_count"] = node.get("_count", 0) + 1
    return root

def collect_common_prefixes(trie: dict, min_count: int = 2, min_len: int = 6) -> list[str]:
    prefixes = []
    def dfs(node, prefix):
        for ch, nxt in node.items():
            if ch == "_count":
                continue
            count = nxt["_count"]
            new_prefix = prefix + ch
            if count >= min_count and len(new_prefix) >= min_len:
                prefixes.append(new_prefix)
            dfs(nxt, new_prefix)
    dfs(trie, "")
    # longer prefixes should come first to avoid partial-color overlapping
    prefixes.sort(key=len, reverse=True)
    return prefixes

def assign_colors_to_prefixes(prefixes: list[str]) -> dict[str, str]:
    mapping = {}
    for i, p in enumerate(prefixes):
        mapping[p] = COLORS[i % len(COLORS)]
    return mapping

def highlight_prefixes(s: str, prefixes: list[str], color_map: dict[str, str]) -> str:
    for p in prefixes:  # longest first
        if s.startswith(p):
            color = color_map.get(p, "")
            return f"{color}{p}{RESET} {s[len(p):]}"
    return f" {s}"

def main():
    ap = argparse.ArgumentParser(
        description="Print message frequencies (and optionally time delta & data) from a processed round JSON."
    )
    ap.add_argument("file", type=Path, help="Path to processed JSON (one round)")

    # frequency printing
    ap.add_argument("--unit", choices=["hz", "khz", "mhz"], default="mhz",
                    help="Output frequency unit (default: mhz)")
    ap.add_argument("--round", type=int, default=None,
                    help="Round frequency values to N decimals (default: none)")

    # selection / ordering (note: when printing delta/data we ignore --unique)
    ap.add_argument("--unique", action="store_true", help="Print unique frequencies only (no deltas/data)")
    ap.add_argument("--sorted", dest="do_sorted", action="store_true",
                    help="Sort frequencies before printing")
    ap.add_argument("--with-index", action="store_true",
                    help="Prefix each line with message index")

    # delta & data
    ap.add_argument("--with-delta", action="store_true",
                    help="Include time delta column (seconds)")
    ap.add_argument("--delta-from", choices=["prev", "first"], default="prev",
                    help="Delta baseline: previous message or first message (default: prev)")
    ap.add_argument("--round-dt", type=int, default=None,
                    help="Round delta values to N decimals (default: none)")
    ap.add_argument("--ts-key", type=str, default=None,
                    help="Timestamp key in each message (auto: tries ts, time, timestamp)")
    ap.add_argument("--ts-unit", choices=["s", "ms", "us", "ns"], default="ms",
                    help="Units for numeric timestamps (default: auto-heuristic)")
    ap.add_argument("--with-snr", action="store_true",
                    help="Include SNR column")

    ap.add_argument("--with-data", action="store_true",
                    help="Include data column")

    # formatting
    ap.add_argument("--sep", type=str, default="\t",
                    help="Output separator (default: '<tab>')")
    ap.add_argument("--header", action="store_true", help="Print header row", default=True)

    ap.add_argument("--detect-common-prefixes", action="store_true",
                    help="Highlight common data prefixes across all messages")

    args = ap.parse_args()

    if not args.file.exists():
        raise SystemExit(f"File not found: {args.file}")

    msgs = load_msgs(args.file)
    if not msgs:
        print("No messages found.")
        return

    # Decide keys
    sample = msgs[0] if msgs else {}
    freq_key = "freq"

    ts_key = "time_us"
    data_key = "data"

    # If printing delta/data, we must iterate per message
    print_per_message = not args.unique

    meta = json.loads(args.file.read_text(encoding="utf-8"))
    rid = meta.get("id", args.file.stem)

    # Build rows
    rows = []
    times_sec: list[Optional[float]] = []
    for m in msgs:
        f = m.get(freq_key)
        if not isinstance(f, (int, float)):
            times_sec.append(None)
            rows.append({"freq_hz": None, "ts_s": None, "data": None})
            continue
        ts_s = normalize_ts(m.get(ts_key), args.ts_unit) if ts_key else None
        times_sec.append(ts_s)
        datum = m.get(data_key) if data_key else None
        rows.append({"id": str(m['id']), "freq_hz": float(f), "ts_s": ts_s, "data": datum, "snr": f"{m['snr']:.2f}"})

    common_prefixes = []
    color_map = {}
    if args.detect_common_prefixes and args.with_data:
        all_data = [str(r["data"]) for r in rows if r.get("data")]
        trie = build_prefix_trie(all_data)
        common_prefixes = collect_common_prefixes(trie)
        color_map = assign_colors_to_prefixes(common_prefixes)

    # Header
    print(f"# file: {args.file.name}  id: {rid}")
    print(f"# messages: {len(rows)}")
    print(f"# unit: {args.unit}  freq_rounding: {args.round}  sep: {repr(args.sep)}")
    if args.with_delta:
        print(f"# delta_from: {args.delta_from}  dt_rounding: {args.round_dt}")
    print()

    # Unique/Sorted mode (freq-only)
    if not print_per_message:
        freqs = [r["freq_hz"] for r in rows if isinstance(r["freq_hz"], (int, float))]
        seq = sorted(set(freqs)) if args.unique else freqs
        if args.do_sorted and not args.unique:
            seq = sorted(seq)

        if args.with_index and not args.unique:
            if args.header:
                print(args.sep.join(["idx", "freq"]))
            for i, f_hz in enumerate(seq):
                print(f"{i}{args.sep}{fmt_freq(f_hz, args.unit, args.round)}")
        else:
            if args.header:
                print("freq")
            for f_hz in seq:
                print(fmt_freq(f_hz, args.unit, args.round))
        return

    # Per-message printing (delta/data path). We ignore --unique because rows must align to messages
    # Compute deltas (in seconds)
    if args.with_delta:
        dts = []
        base = None if args.delta_from == "prev" else (times_sec[0] if times_sec else None)
        prev = None
        for t in times_sec:
            if t is None:
                dts.append(None)
            else:
                if args.delta_from == "prev":
                    if prev is None:
                        dts.append(0.0)
                    else:
                        dts.append(t - prev)
                    prev = t
                else:  # first
                    if base is None:
                        dts.append(None)
                    else:
                        dts.append(t - base)
        # attach
        for r, dt in zip(rows, dts):
            r["dt_s"] = dt
    else:
        for r in rows:
            r["dt_s"] = None

    # Header row for CSV/TSV
    hdr = []
    if args.with_index:
        hdr.append("idx")
    hdr.append("freq")
    if args.with_delta:
        hdr.append("delta")
    if args.with_snr:
        hdr.append("snr")
    if args.with_data:
        hdr.append(data_key or "data")
    if args.header:
        print(args.sep.join(hdr))

    if args.do_sorted:
        rows.sort(key=lambda r: (r["freq_hz"] if r["freq_hz"] is not None else float('inf')))

    # Emit rows
    for i, r in enumerate(rows):
        out = []
        if args.with_index:
            out.append(r['id'])
        out.append(fmt_freq(r["freq_hz"], args.unit, args.round) if r["freq_hz"] is not None else "NA")
        if args.with_delta:
            out.append(fmt_num(r.get("dt_s"), args.round_dt))
        if args.with_snr:
            out.append(r.get("snr", "NA"))
        if args.with_data:
            v = r["data"]
            if v is None:
                out.append("")
            else:
                s = str(v).replace("\n", "\\n").replace("\r", "\\r")
                if common_prefixes:
                    s = highlight_prefixes(s, common_prefixes, color_map)
                out.append(s)
        print(args.sep.join(out))

if __name__ == "__main__":
    main()
