#!/usr/bin/env python3
import struct
import json
import argparse

# 16s = 16-byte string (encryption_key)
# I   = uint32_t - central_frequency
# I   = uint32_t - channel_width
# B   = uint8_t - channels_count
# B   = uint8_t - sync_channel1
# B   = uint8_t - sync_channel2
# B   = uint8_t - unknown
STRUCT_FORMAT = "<16sIIBBBB"
STRUCT_SIZE = struct.calcsize(STRUCT_FORMAT)


def read_config(path, offset_val=0x10000):
    with open(path, "rb") as f:
        f.seek(offset_val)
        data = f.read(STRUCT_SIZE)

    if len(data) < STRUCT_SIZE:
        raise ValueError(f"Not enough data at offset 0x{offset_val:X}")

    encryption_key, central_freq, ch_width, ch_count, sync1, sync2, unknown = struct.unpack(STRUCT_FORMAT, data)

    return {
        "encryption_key_hex": encryption_key.hex(),
        "central_frequency": central_freq,
        "channel_width": ch_width,
        "channels_count": ch_count,
        "sync_channels": [sync1, sync2],
        "unknown": unknown
    }


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Read one config struct from binary firmware dump.")
    ap.add_argument("binfile", help="Binary file path")
    ap.add_argument("--offset", default="0x10000",
                    help="Offset in hex or decimal (default 0x1000)")
    args = ap.parse_args()

    offset = int(args.offset, 0)
    config = read_config(args.binfile, offset)

    print(json.dumps(config, indent=2, ensure_ascii=False))
