# ---- GPIO device ------------------------------------------------------------
class GpioPort:
    # Base addresses (APB1)
    BASES = {
        0x4001F000: "A",
        0x4001F400: "B",
        0x4001F800: "C",
        0x4001FC00: "D",
    }

    # Offsets (Table 11-1)
    OER      = 0x00  # output enable
    OTYPER   = 0x04
    IER      = 0x08  # input enable
    PER      = 0x0C  # pull enable
    PSR      = 0x10  # pull select
    IDR      = 0x14  # input data
    ODR      = 0x18  # output data
    BRR      = 0x1C  # bit reset (write-1-to-clear)
    BSRR     = 0x20  # bit set/reset (lower 16 set, upper 16 reset)
    DSR      = 0x24
    INT_CR   = 0x28
    FR       = 0x2C  # interrupt flags (rw1c?)
    WU_EN    = 0x30
    WU_LVL   = 0x34
    AFRL     = 0x38  # pins 0..7
    AFRH     = 0x3C  # pins 8..15
    STOP3_WU = 0x40

    def __init__(self, base, dprint=print):
        self.base = base
        self.name = self.BASES.get(base, "?")
        self._regs = {
            self.OER:  0x00000000,
            self.OTYPER: 0x00000000,
            self.IER:  0x0000FFFF,   # assume inputs enabled by default
            self.PER:  0x00000000,
            self.PSR:  0x00000000,
            self.IDR:  0x00000000,   # live inputs
            self.ODR:  0x00000000,   # latched outputs
            self.DSR:  0x00000000,
            self.INT_CR: 0x00000000,
            self.FR:   0x00000000,
            self.WU_EN: 0x00000000,
            self.WU_LVL:0x00000000,
            self.AFRL: 0x00000000,
            self.AFRH: 0x00000000,
            self.STOP3_WU:0x00000000,
        }
        # per-pin callbacks: (old, new) -> None
        self.on_output_change = {i: None for i in range(16)}
        self.on_direction_change = {i: None for i in range(16)}
        self.dprint = dprint

    # Integrates with your device bus
    def handles(self, addr):
        return self.base <= addr < self.base + 0x44

    def _pin_mask(self, val): return val & 0xFFFF

    def _log_bits(self, old, new, label):
        diff = (old ^ new) & 0xFFFF
        if diff:
            self.dprint(f"[GPIO{self.name}] {label}: 0x{old:04X} -> 0x{new:04X}")

    def _emit_output_callbacks(self, old_odr, new_odr):
        chg = (old_odr ^ new_odr) & 0xFFFF
        while chg:
            i = (chg & -chg).bit_length() - 1
            old_b = (old_odr >> i) & 1
            new_b = (new_odr >> i) & 1
            cb = self.on_output_change.get(i)
            if cb:
                try: cb(old_b, new_b)
                except Exception: pass
            chg &= chg - 1

    def _emit_dir_callbacks(self, old_oer, new_oer):
        chg = (old_oer ^ new_oer) & 0xFFFF
        while chg:
            i = (chg & -chg).bit_length() - 1
            cb = self.on_direction_change.get(i)
            if cb:
                try: cb((old_oer>>i)&1, (new_oer>>i)&1)
                except Exception: pass
            chg &= chg - 1

    def read(self, uc, addr, size):
        off = addr - self.base
        # IDR reflects live input levels; for outputs many MCUs mirror ODR—do the same
        if off == self.IDR:
            val = (self._regs[self.IDR])
            for pin in range(16):
                bit_val = (val >> pin) & 1
                self.dprint(f"[GPIO{self.name}{pin}] read as {bit_val}")
        else:
            val = self._regs.get(off, 0)
        return val & ((1 << (size*8)) - 1)

    def write(self, uc, addr, size, value):
        off = addr - self.base
        val = value & ((1 << (size*8)) - 1)
        regs = self._regs

        if off == self.ODR:
            old = regs[self.ODR] & 0xFFFF
            new = self._pin_mask(val)
            self._regs[self.ODR] = new
            self._log_bits(old, new, "ODR")
            self._emit_output_callbacks(old, new)
            return True

        if off == self.BRR:
            # write-1-to-clear bits
            old = regs[self.ODR] & 0xFFFF
            clr = self._pin_mask(val)
            new = old & ~clr
            self._regs[self.ODR] = new
            self._log_bits(old, new, "BRR->ODR")
            self._emit_output_callbacks(old, new)
            return True

        if off == self.BSRR:
            # lower 16 set; upper 16 reset
            set_mask = self._pin_mask(val)
            rst_mask = self._pin_mask(val >> 16)
            old = regs[self.ODR] & 0xFFFF
            new = (old | set_mask) & ~rst_mask
            self._regs[self.ODR] = new
            self._log_bits(old, new, "BSRR->ODR")
            self._emit_output_callbacks(old, new)
            return True

        if off == self.OER:
            old = regs[self.OER] & 0xFFFF
            new = self._pin_mask(val)
            self._regs[self.OER] = new
            self._log_bits(old, new, "OER(dir:1=out)")
            self._emit_dir_callbacks(old, new)
            return True

        if off in (self.IER, self.PER, self.PSR, self.OTYPER, self.DSR, self.INT_CR, self.WU_EN, self.WU_LVL, self.STOP3_WU):
            old = regs.get(off, 0)
            regs[off] = val
            self._log_bits(old, val, f"WR off=0x{off:02X}")
            return True

        if off in (self.AFRL, self.AFRH):
            old = regs.get(off, 0)
            regs[off] = val
            # Optional: decode AF per pin for logging
            if off == self.AFRL:
                af = [ (val >> (i*4)) & 0xF for i in range(8) ]
                self.dprint(f"[GPIO{self.name}] AFRL set: {af}")
            else:
                af = [ (val >> (i*4)) & 0xF for i in range(8) ]
                self.dprint(f"[GPIO{self.name}] AFRH set: {af} (pins 8..15)")
            return True

        # Writes to IDR are ignored (read-only)
        self._regs[off] = val
        return True

    # --- External helpers so *you* can drive inputs and observe outputs ----
    def set_input(self, pin, level):
        """Drive an external input level (0/1)."""
        mask = 1 << pin
        old = self._regs[self.IDR] & 0xFFFF
        new = (old | mask) if level else (old & ~mask)
        if new != old:
            self._regs[self.IDR] = new
            self.dprint(f"[GPIO{self.name}] IDR ext {pin} <- {level}")

    def get_output(self, pin):
        return (self._regs[self.ODR] >> pin) & 1

    def get_dir(self, pin):
        return (self._regs[self.OER] >> pin) & 1  # 1=output

class GpioBus:
    def __init__(self, dprint=print):
        self.ports = [GpioPort(base, dprint=dprint) for base in sorted(GpioPort.BASES)]
        self.by_base = {p.base: p for p in self.ports}
        self.by_name = {p.name: p for p in self.ports}
        self.dprint = dprint

    def handles(self, addr):
        for p in self.ports:
            if p.handles(addr): return True
        return False

    def _port(self, addr):
        for p in self.ports:
            if p.handles(addr): return p
        return None

    def read(self, uc, addr, size):
        return self._port(addr).read(uc, addr, size)

    def write(self, uc, addr, size, value):
        return self._port(addr).write(uc, addr, size, value)
# -----------------------------------------------------------------------------
