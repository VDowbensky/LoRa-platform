import argparse

from elftools.elf.elffile import ELFFile


def format_hex_bytes(data: bytes, limit: int = 10) -> str:
    return ' '.join(f'{b:02x}' for b in data[:limit])


def vaddr_to_offset(elf: ELFFile, vaddr: int) -> int:
    """Convert virtual address to file offset using program headers"""
    for segment in elf.iter_segments():
        seg_start = segment['p_vaddr']
        seg_end = seg_start + segment['p_memsz']
        if seg_start <= vaddr < seg_end:
            return segment['p_offset'] + (vaddr - seg_start)
    raise ValueError(f"Address {hex(vaddr)} not in any segment")


def extract_functions_with_bytes(elf_path, limit: int = 10):
    with open(elf_path, "rb") as f:
        elf = ELFFile(f)
        symtab = elf.get_section_by_name(".symtab")
        text_section = elf.get_section_by_name(".text")

        if not symtab or not text_section:
            print("Missing symbol table or .text section.")
            return

        functions = {}

        for symbol in symtab.iter_symbols():
            if symbol['st_info']['type'] == 'STT_FUNC' and symbol['st_size'] > 0:
                name = symbol.name
                addr = symbol['st_value']
                size = symbol['st_size']
                try:
                    file_offset = vaddr_to_offset(elf, addr - 1)
                    f.seek(file_offset)
                    bytes_seq = f.read(size)
                    functions[name] = format_hex_bytes(bytes_seq, limit)
                except ValueError as e:
                    print(f"[!] Skipping {name}: {e}")

        return functions


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Extract functions and their first bytes from an ELF file in a for of python ")
    parser.add_argument("elf_path", help="Path to the ELF file")
    parser.add_argument("--limit", type=int, default=10,
                        help="Limit the number of bytes to display per function (default: 10)")

    args = parser.parse_args()

    result = extract_functions_with_bytes(args.elf_path, limit=args.limit)
    if result:
        print('{')
        for name, hexbytes in result.items():
            if len(hexbytes) > args.limit:
                print(f"'{name}': bytes.fromhex('{hexbytes}'),")
        print('}')
