#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
from statistics import mean, median

PROCESSED_DIR = Path("spectrofy_data/processed")

def load_rounds(path: Path):
    rounds = []
    for p in sorted(path.glob("*.json")):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
            msgs = d.get("msgs", []) or []
            freqs = [m.get("freq") for m in msgs if "freq" in m]
            freqs = [int(f) for f in freqs if isinstance(f, (int, float))]
            uniq_freqs = sorted(set(freqs))
            rounds.append({
                "file": p.name,
                "id": d.get("id", p.stem),
                "num_msgs": len(msgs),
                "uniq_freqs_count": len(uniq_freqs),
                "uniq_freqs": uniq_freqs,
            })
        except Exception as e:
            print(f"⚠️ Skipping {p}: {e}")
    return rounds

def tukey_outliers(values):
    if not values:
        return set(), set()
    xs = sorted(values)
    n = len(xs)
    q1 = xs[n//4]
    q3 = xs[(3*n)//4]
    iqr = q3 - q1
    low_fence = q1 - 1.5*iqr
    high_fence = q3 + 1.5*iqr
    low_idx = {i for i, v in enumerate(values) if v < low_fence}
    high_idx = {i for i, v in enumerate(values) if v > high_fence}
    return low_idx, high_idx

def is_equal_step(freqs_hz, tol_hz=1000):
    if len(freqs_hz) < 3:
        return False, None
    diffs = [freqs_hz[i+1] - freqs_hz[i] for i in range(len(freqs_hz)-1)]
    step = int(median(diffs))
    ok = all(abs(d - step) <= tol_hz for d in diffs)
    return ok, step if ok else None

def hz_to_mhz(hz):
    return hz / 1e6

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--processed", default=str(PROCESSED_DIR))
    ap.add_argument("--step-tol-hz", type=int, default=1e6)
    args = ap.parse_args()

    rounds = load_rounds(Path(args.processed))
    if not rounds:
        print("No rounds found.")
        return

    num_msgs = [r["num_msgs"] for r in rounds]
    uniq_counts = [r["uniq_freqs_count"] for r in rounds]

    msg_min, msg_max, msg_avg = min(num_msgs), max(num_msgs), mean(num_msgs)
    uf_min, uf_max, uf_avg = min(uniq_counts), max(uniq_counts), mean(uniq_counts)

    # Find the record with max messages
    idx_max = num_msgs.index(msg_max)
    max_round = rounds[idx_max]

    print("\n=== Summary ===")
    print(f"Rounds analyzed: {len(rounds)}")
    print(f"Messages per round: min={msg_min}, max={msg_max}, avg={msg_avg:.2f}")
    print(f"Unique freqs per round: min={uf_min}, max={uf_max}, avg={uf_avg:.2f}")

    print("\n=== Max messages round ===")
    print(f"File: {max_round['file']}, id={max_round['id']}, messages={max_round['num_msgs']}, "
          f"unique freqs={max_round['uniq_freqs_count']}")

    print("\n=== Perfect rounds (equal-step frequencies) ===")
    for r in rounds:
        ok, step = is_equal_step(r["uniq_freqs"], tol_hz=args.step_tol_hz)
        if ok:
            print(f"- {r['file']} msgs={r['num_msgs']} step≈{hz_to_mhz(step):.2f} MHz min={hz_to_mhz(r['uniq_freqs'][0]):.2f} MHz max={hz_to_mhz(r['uniq_freqs'][-1]):.2f} MHz  uniq_freqs={r['uniq_freqs_count']}")
if __name__ == "__main__":
    main()
