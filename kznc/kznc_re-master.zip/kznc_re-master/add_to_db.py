#!/usr/bin/env python3

import yaml
from pathlib import Path


def add_record_to_yaml(file_path, values):
    binary_file = Path(file_path)
    directory = binary_file.parent.as_posix()

    db_file = (Path(directory) / "db.yaml").as_posix()

    yaml_path = Path(db_file)

    # Create empty file if it doesn't exist
    if not yaml_path.exists():
        yaml_path.write_text("[]\n", encoding="utf-8")

    # Load existing YAML
    with open(yaml_path, "r", encoding="utf-8") as f:
        try:
            data = yaml.safe_load(f) or []
        except yaml.YAMLError:
            data = []

    # Append new record
    data.append({
        "file": binary_file.name,
        **values,
    })

    # Save back to YAML
    with open(yaml_path, "w", encoding="utf-8") as f:
        yaml.dump(data, f, sort_keys=False)


if __name__ == '__main__':
    print("Example input:")
    print('dumps/<date>/kznc_dump_<date>__<n>.bin')
    print('serial: ****')
    print('option 0: ******** ********')
    print('option 1: ******** ********')
    print('')
    print("Enter data: (Press Enter on an empty line to finish)")
    lines = []
    while True:
        line = input().strip()
        if not line:
            break
        lines.append(line)

    for line in lines:
        print(line)

    file_path = lines[0]
    serial = lines[1].split(": ")[1].strip()
    options = {}
    for i in range(2, len(lines)):
        option_name, option_values = lines[i].split(": ")
        options[option_name] = option_values.strip().split()
    add_record_to_yaml(file_path, {
        "serial": serial,
        **options
    })
