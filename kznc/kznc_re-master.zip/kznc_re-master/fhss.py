
def generate_fhss_frequencies(central_frequency_hz: float, channel_width_hz: float, channels_count: int):
    channels_before = (channels_count - 1) // 2 + 1

    # Calculate start so that central_frequency_hz is exactly one channel
    start_frequency_hz = central_frequency_hz - (channels_before * channel_width_hz)

    return [start_frequency_hz + i * channel_width_hz for i in range(channels_count)]
