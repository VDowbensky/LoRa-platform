# KZNC RE

## Requirements

- python3

## [Notes](https://github.com/evil-lrs/kznc_re/blob/master/notes.md)

## Scripts

- `run_unicorn_emulator.py` - Runs the binary in a Unicorn emulator.
- `analyze_dumps.py` - Analyzes existing dumps and generates a report.
- `parse_config.py` - Parses configuration from provided binary file.

## How to add new dump?

1. Add new folder at dumps/ with date or some other identifier if need.
2. Run `python dump_flash.py --port /dev/cu.usbserial-*** --output 'dumps/<date>/kznc_dump_<date>__<n>.bin`.
3. Run `python add_to_db.py` and enter output from previous step to add the new dump to the database file.
4. Run `python analyze_dumps.py --run-emulation --report md --out report.md` to update a report.


```bash
./analyze_dumps.py --run-emulation --report json --out report.json --plot-fhss-ranges --plot-fhss-ranges-label="notes"
./analyze_dumps.py --run-emulation --report md --out report.md --plot-fhss-ranges --plot-fhss-ranges-label="#"
```