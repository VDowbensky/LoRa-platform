from typing import Iterable, Tuple

import matplotlib.pyplot as plt

FHSSRow = Tuple[str, int, float, float]


def plot_fhss_ranges(
        rows: Iterable[FHSSRow],
        sort_by: str = "fmin",  # "fmin" | "fmax" | "label" | None
        annotate: bool = True,  # show "#<channel>" labels at bar ends
        xlabel: str = "Frequency (MHz)",
        ylabel: str = "",  # empty -> no Y axis label
        grid: bool = True,
):
    rows = [r for r in rows if isinstance(r, tuple) and len(r) == 4]

    # Sorting
    if sort_by == "fmin":
        rows.sort(key=lambda r: r[2])
    elif sort_by == "fmax":
        rows.sort(key=lambda r: r[3])
    elif sort_by == "label":
        rows.sort(key=lambda r: r[0])

    # Build plot
    fig = plt.figure(figsize=(12, 6))
    ax = fig.gca()

    for idx, (label, cnt, fmin, fmax) in enumerate(rows, start=1):
        ax.barh(idx, fmax - fmin, left=fmin, height=0.6, alpha=0.6)
        if annotate:
            ax.text(fmax + 0.3, idx, f"{label}", va="center")

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if not ylabel:
        ax.set_yticks([])

    if grid:
        ax.grid(axis="x", linestyle="--", alpha=0.7)
    else:
        ax.grid(False)

    fig.tight_layout()

    return fig, ax


if __name__ == '__main__':
    # --- Demo with your data and save to file ---
    channels = [
        (1, 100, 318.75, 331.125),
        (2, 70, 331.25, 348.5),
        (3, 20, 332, 341.5),
        (4, 24, 322, 327.75),
        (5, 100, 277.5, 302.25),
        (6, 20, 332, 341.5),
        (7, 20, 332, 341.5),
        (8, 120, 325, 354.75),
        (9, 200, 290, 339.75),
        (10, 20, 332, 341.5),
        (11, 20, 332, 341.5),
        (12, 20, 332, 341.5),
        (13, 20, 332, 341.5),
        (14, 20, 332, 341.5),
        (15, 20, 359, 368.5),
        (16, 20, 332, 341.5),
    ]

    outfile = "fhss_plot.png"

    fig, ax = plot_fhss_ranges(channels)
    fig.show()

    if outfile:
        fig.savefig(outfile, dpi=150, bbox_inches="tight")
