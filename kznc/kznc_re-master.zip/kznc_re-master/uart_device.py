import collections
import struct

UART0_BASE = 0x40003000  # APB0: UART0


class UartDevice:
    """
    Minimal UART model for ASR6601 UARTx:
      - Base + 0x00: DR (data)
      - Base + 0x18: FR (flags)
    Emulates RXFE and TXFF bits; exposes enqueue() and get_tx_bytes().
    """

    # Flag bits (PL011-like; only what we need)
    FR_TXFE = 1 << 7  # TX FIFO empty
    FR_RXFF = 1 << 6  # RX FIFO full
    FR_TXFF = 1 << 5  # TX FIFO full
    FR_RXFE = 1 << 4  # RX FIFO empty
    FR_BUSY = 1 << 3  # busy (TX FIFO not empty)

    REG_DR = 0x00
    REG_FR = 0x18

    def __init__(self, base_addr: int, tx_cb=None, rx_fifo_size=64, tx_fifo_size=64, dprint=lambda *a, **k: None):
        self.base = base_addr
        self.tx_cb = tx_cb
        self.rx_fifo = collections.deque(maxlen=rx_fifo_size)
        self.tx_fifo = collections.deque(maxlen=tx_fifo_size)
        self._fr = self.FR_RXFE  # start with RX empty, TX not full
        self.dprint = dprint

    # --- helpers ---
    def _update_fr(self):
        # RXFE bit reflects whether RX queue is empty
        if self.rx_fifo:
            self._fr &= ~self.FR_RXFE
        else:
            self._fr |= self.FR_RXFE

        # TXFF bit reflects whether TX queue is full
        if len(self.tx_fifo) >= self.tx_fifo.maxlen:
            self._fr |= self.FR_TXFF
        else:
            self._fr &= ~self.FR_TXFF

    def enqueue(self, data: bytes | str):
        if isinstance(data, str):
            data = data.encode("ascii", "ignore")
        for b in data:
            if len(self.rx_fifo) < self.rx_fifo.maxlen:
                self.rx_fifo.append(b)
        self._update_fr()

    def get_tx_bytes(self) -> bytes:
        data = bytes(self.tx_fifo)
        self.tx_fifo.clear()
        self._update_fr()
        return data

    # --- MMIO interface ---
    def handles(self, addr: int) -> bool:
        return addr in (self.base + self.REG_DR, self.base + self.REG_FR)

    def read(self, uc, addr: int, size: int) -> int:
        off = addr - self.base
        if off == self.REG_FR:
            self._update_fr()
            val = self._fr & 0xFFFFFFFF
            uc.mem_write(addr, struct.pack("<I", val))
            self.dprint(f"[UART] FR read -> 0x{val:08X}")
            return val

        if off == self.REG_DR:
            if self.rx_fifo:
                b = self.rx_fifo.popleft()
            else:
                b = 0
            self._update_fr()
            uc.mem_write(addr, struct.pack("<I", b))
            self.dprint(f"[UART] DR read -> 0x{b:02X} '{chr(b) if 32 <= b < 127 else '.'}'")
            return b

        # unreachable with handles()
        return 0

    def write(self, uc, addr: int, size: int, value: int):
        off = addr - self.base
        if off == self.REG_DR:
            b = value & 0xFF
            if len(self.tx_fifo) < self.tx_fifo.maxlen:
                self.tx_fifo.append(b)
            self._update_fr()
            self.dprint(f"[UART] DR write <- 0x{b:02X} '{chr(b) if 32 <= b < 127 else '.'}'")
            if self.tx_cb:
                try:
                    self.tx_cb(b)
                except Exception:
                    pass
            return True
        # ignore writes to FR (RO in our model)
        return True
