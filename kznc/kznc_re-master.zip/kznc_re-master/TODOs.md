# TODOs

- [x] add correct size checking for binary dumps before analysis
- [ ] 