#!/usr/bin/env python3
import json
from pathlib import Path

RAW_DIR = Path("spectrofy_data/raw")
OUT_DIR = Path("spectrofy_data/processed")


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    for infile in RAW_DIR.glob("*.jsonl"):
        try:
            with open(infile, "r", encoding="utf-8") as f:
                # Each line is a JSON object (not a JSON array)
                for line_num, line in enumerate(f, start=1):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                    except json.JSONDecodeError as e:
                        print(f"❌ Failed to parse {infile}:{line_num}: {e}")
                        continue

                    # Build output filename
                    round_id = data.get("id", f"{infile.stem}_{line_num}")
                    outfile = OUT_DIR / f"{round_id}.json"

                    with open(outfile, "w", encoding="utf-8") as out:
                        json.dump(data, out, ensure_ascii=False, indent=2)

                    print(f"✅ Wrote {outfile}")
        except Exception as e:
            print(f"⚠️ Error processing {infile}: {e}")


if __name__ == "__main__":
    main()
