# Firmware structure

## Config

At address `0x10000` is the configuration area, which contains various settings for the firmware.
Structure:
```c
struct {
  uint8_t encryption_key[0x10];
  uint32_t central_frequency;
  uint32_t channel_width;
  uint8_t channels_count;
  uint8_t sync_channels[2];
  uint8_t unknown; // probably payload length, never referenced
};
```

# Links

 - The LoRa Air-Time Calculator: https://iftnt.github.io/lora-air-time/index.html
 - sx1262 datasheet: https://semtech.my.salesforce.com/sfc/p/E0000000JelG/a/RQ000008nKCH/hp2iKwMDKWl34g1D3LBf_zC7TGBRIo2ff5LMnS8r19s
 - SDK: https://github.com/Ai-Thinker-Open/Ai-Thinker-LoRaWAN-Ra-08/tree/main/lora/driver
 - Ra-08: https://uamper.com/Ra08-LoRa-module-ASR6601-433MHz
