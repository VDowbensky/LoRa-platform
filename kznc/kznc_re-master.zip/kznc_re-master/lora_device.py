from collections import deque

SF_DESC = {
    5: 'SF5',
    6: 'SF6',
    7: 'SF7',
    8: 'SF8',
    9: 'SF9',
    10: 'SF10',
    11: 'SF11',
    12: 'SF12'
}
BW_DESC = {
    0: '7.81 kHz',
    8: '10.42 kHz',
    1: '15.63 kHz',
    9: '20.83 kHz',
    2: '31.25 kHz',
    10: '41.67 kHz',
    3: '62.50 kHz',
    4: '125 kHz',
    5: '250 kHz',
    6: '500 kHz'
}
CR_DESC = {
    1: '4/5',
    2: '4/6',
    3: '4/7',
    4: '4/8'
}
IRQ_BITS = {
    0x0001: "RX_DONE",
    0x0002: "TX_DONE",
    0x0004: "PreambleDetected",
    0x0008: "SyncWordValid",
    0x0010: "HeaderValid",
    0x0020: "HeaderErr",
    0x0040: "CRCErr",
    0x0080: "CADDone",
    0x0100: "CADDetected",
    0x0200: "Timeout",
}

HEADER_TYPES = {0: "explicit", 1: "implicit"}


class Sx126xStub:
    # chip modes (matches GetStatus "chip mode" field 6:4; we only use a couple)
    MODE_STBY_RC = 0x2
    MODE_STBY_XOSC = 0x3
    MODE_FS = 0x4
    MODE_RX = 0x5
    MODE_TX = 0x6

    # opcodes we emulate (subset)
    OP_GET_STATUS = 0xC0  # host sends: C0, NOP  -> returns RFU, status
    OP_SET_STANDBY = 0x80  # C0 per table 13-3, param: 0=RC, 1=XOSC
    OP_SET_FS = 0xC1
    OP_WRITE_REGISTER = 0x0D
    OP_READ_REGISTER = 0x1D
    OP_WRITE_BUFFER = 0x0E
    OP_READ_BUFFER = 0x1E
    OP_SET_BUFFER_BASE_ADDR = 0x8F
    OP_SET_REGULATOR_MODE = 0x96
    OP_CALIBRATE = 0x89
    OP_CALIBRATE_IMAGE = 0x98
    OP_SET_DIO3_AS_TCXO_CTRL = 0x97
    # SetDIO2AsRfSwitchCtrl 0x9D
    OP_SET_DIO2_AS_RF_SWITCH_CTRL = 0x9D
    # SetDioIrqParams 0x08
    OP_SET_DIO_IRQ_PARAMS = 0x08
    # SetPaConfig 0x95
    OP_SET_PA_CONFIG = 0x95
    # SetTxParams 0x8E
    OP_SET_TX_PARAMS = 0x8E

    OP_SET_RX = 0x82
    OP_SET_TX = 0x83
    OP_SET_RF_FREQUENCY = 0x86
    OP_SET_PACKET_TYPE = 0x8A
    OP_SET_MODULATION_PARAMS = 0x8B
    OP_SET_PACKET_PARAMS = 0x8C
    OP_SET_RXTX_FALLBACK_MODE = 0x93
    OP_STOP_TIMER_ON_PREAMBLE = 0x9F
    OP_SET_LORA_SYMB_NUM_TIMEOUT = 0xA0

    def __init__(self, dprint=lambda *a, **k: None, cmd_cb=lambda *a, **k: None, result_cb=lambda *a, **k: None):
        self.dprint = dprint
        self.cmd_cb = cmd_cb
        self.result_cb = result_cb
        self.reset()
        self.existing_ops = {
            self.OP_GET_STATUS,
            self.OP_SET_STANDBY,
            self.OP_SET_FS,
            self.OP_WRITE_REGISTER,
            self.OP_READ_REGISTER,
            self.OP_WRITE_BUFFER,
            self.OP_READ_BUFFER,
            self.OP_SET_BUFFER_BASE_ADDR,
            self.OP_SET_REGULATOR_MODE,
            self.OP_CALIBRATE,
            self.OP_CALIBRATE_IMAGE,
            self.OP_SET_DIO3_AS_TCXO_CTRL,
            self.OP_SET_DIO2_AS_RF_SWITCH_CTRL,
            self.OP_SET_DIO_IRQ_PARAMS,
            self.OP_SET_PA_CONFIG,
            self.OP_SET_TX_PARAMS,

            self.OP_SET_RX,
            self.OP_SET_TX,
            self.OP_SET_RF_FREQUENCY,
            self.OP_SET_PACKET_TYPE,
            self.OP_SET_MODULATION_PARAMS,
            self.OP_SET_PACKET_PARAMS,
            self.OP_SET_RXTX_FALLBACK_MODE,
            self.OP_STOP_TIMER_ON_PREAMBLE,
            self.OP_SET_LORA_SYMB_NUM_TIMEOUT,

        }

    # --- host-visible state we mirror onto LoRaC SR bits ---
    @property
    def busy(self):
        return self._busy > 0

    @property
    def clk32_ready(self):
        return self._clk32_ready

    # --- transaction framing (NSS low/high) ---
    def start(self):
        self._rx_queue.clear()
        self._tx_stream_index = 0
        self._opcode = None
        self._argbuf = []
        self._read_count_left = None
        self._read_source = None
        self._pending_status_after = 0  # how many bytes until we put status on MISO
        self.dprint("[SX126x] CS low - start")

    def end(self):
        # any command that only latches on CS high can finish here (we don’t need it for our subset)
        self.dprint("[SX126x] CS high - end")

    # one SPI byte in → one SPI byte out
    def shift(self, mosi_byte):
        # If we have already prepared a response stream, return next byte from it.
        if self._rx_queue:
            b = self._rx_queue.popleft()
            return b

        # OpCode phase
        if self._opcode is None:
            self._opcode = mosi_byte
            self.dprint(f"[SX126x] OPCODE 0x{self._opcode:02X}")
            # For most commands, datasheet says first returned byte during opcode phase is RFU=0x00,
            # then the status appears on a subsequent byte. We’ll queue RFU now.
            self._rx_queue.append(0x00)
            # Some commands immediately know how many argument bytes to expect:
            if self._opcode == self.OP_GET_STATUS:
                # Next byte clocks out STATUS
                self._pending_status_after = 1
            elif self._opcode in (self.OP_SET_STANDBY, self.OP_SET_REGULATOR_MODE):
                self._need_args = 1
            elif self._opcode == self.OP_SET_FS:
                self._need_args = 0
            elif self._opcode in (self.OP_CALIBRATE,):
                self._need_args = 1
            elif self._opcode in (self.OP_CALIBRATE_IMAGE,):
                self._need_args = 2
            elif self._opcode in (self.OP_SET_DIO3_AS_TCXO_CTRL,):
                self._need_args = 4  # voltage + 3-byte timeout
            elif self._opcode == self.OP_SET_BUFFER_BASE_ADDR:
                self._need_args = 2
            elif self._opcode == self.OP_WRITE_REGISTER:
                self._need_args = 2  # address hi, lo; then data bytes until CS high
                self._write_reg_addr = None
            elif self._opcode == self.OP_READ_REGISTER:
                self._need_args = 2  # then NOPs clock out data
                self._read_reg_addr = None
            elif self._opcode == self.OP_WRITE_BUFFER:
                self._need_args = 1  # offset; then data until CS high
                self._write_buf_off = None
            elif self._opcode == self.OP_READ_BUFFER:
                self._need_args = 1  # offset; then NOPs clock out data
                self._read_buf_off = None
            elif self._opcode == self.OP_SET_DIO2_AS_RF_SWITCH_CTRL:
                self._need_args = 1
            elif self._opcode == self.OP_SET_DIO_IRQ_PARAMS:  # SetDioIrqParams (0x08) Irq Mask(15:0) DIO1Mask(15:0) DIO2Mask(15:0) DIO3Mask(15:0)
                self._need_args = 8  # 4 bytes for IRQ mask and DIO masks
            elif self._opcode == self.OP_SET_PA_CONFIG:  # Opcode = 0x95 paDutyCycle hpMax deviceSel (0: SX1262, 1: SX1261) paLut
                self._need_args = 4  # 4 bytes for paDutyCycle, hpMax, deviceSel, paLut
            elif self._opcode == self.OP_SET_TX_PARAMS:  # Opcode = 0x8E txPower, rampTime
                self._need_args = 2  # txPower, rampTime
            elif self._opcode == self.OP_SET_TX:
                self._need_args = 3  # timeout[23:0] (we accept 3 bytes per DS)
            elif self._opcode == self.OP_SET_RF_FREQUENCY:  # 0x86
                self._need_args = 4
            elif self._opcode == self.OP_SET_PACKET_TYPE:  # 0x8A
                self._need_args = 1
            elif self._opcode == self.OP_SET_MODULATION_PARAMS:  # 0x8B
                # LoRa = 3 bytes, GFSK = 8 bytes
                if self._packet_type == 1:  # 1 = LoRa, 0 = GFSK
                    self._need_args = 3
                else:
                    self._need_args = 8
            elif self._opcode == self.OP_SET_PACKET_PARAMS:  # 0x8C
                # LoRa uses 6 bytes, GFSK uses 9 bytes (per DS)
                if self._packet_type == 1:  # 1 = LoRa
                    self._need_args = 6
                else:  # 0 = GFSK
                    self._need_args = 9
            elif self._opcode == self.OP_SET_RXTX_FALLBACK_MODE:  # 0x93
                self._need_args = 1
            elif self._opcode == self.OP_STOP_TIMER_ON_PREAMBLE:  # 0x9F
                self._need_args = 1
            elif self._opcode == self.OP_SET_LORA_SYMB_NUM_TIMEOUT:  # 0xA0
                self._need_args = 1
            elif self._opcode == self.OP_SET_RX:  # 0x82
                self._need_args = 3  # timeout[23:0] (we accept 3 bytes per DS)


            else:
                # unknown opcode → command processing error in status; we’ll still swallow until CS high
                self._need_args = 0
                self._last_cmd_error = True

            return self._rx_queue.popleft()

        # arguments / data phase
        self._argbuf.append(mosi_byte)

        # Handle “status appears after N bytes” pattern
        if self._pending_status_after > 0:
            self._pending_status_after -= 1
            if self._pending_status_after == 0:
                self._rx_queue.append(self._make_status())
                return self._rx_queue.popleft()

        result = self.execute_cmd(mosi_byte)

        return result

    def execute_cmd(self, mosi_byte):
        # Decode by opcode
        op = self._opcode

        # ---- Simple “command only” (no args) ----
        if op == self.OP_SET_FS and len(self._argbuf) == 0:
            self._do_set_busy_ticks(2)
            self._mode = self.MODE_FS
            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_SET_FS mode={self._mode}')
            return self._rx_queue.popleft()

        # ---- Fixed small-arg commands ----
        if op == self.OP_SET_STANDBY and len(self._argbuf) == 1:
            cfg = self._argbuf[0] & 1
            self._mode = self.MODE_STBY_XOSC if cfg == 1 else self.MODE_STBY_RC
            self._clk32_ready = (cfg == 1)
            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_SET_STANDBY mode={self._mode} clk32_ready={self._clk32_ready}')
            return self._rx_queue.popleft()

        if op == self.OP_SET_REGULATOR_MODE and len(self._argbuf) == 1:
            self._reg_mode = self._argbuf[0] & 1
            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_SET_REGULATOR_MODE reg_mode={self._reg_mode}')
            return self._rx_queue.popleft()

        if op == self.OP_CALIBRATE and len(self._argbuf) == 1:
            self._do_set_busy_ticks(3)
            self._calib_mask = self._argbuf[0]
            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_CALIBRATE calib_mask=0x{self._calib_mask:02X}')
            return self._rx_queue.popleft()

        if op == self.OP_CALIBRATE_IMAGE and len(self._argbuf) == 2:
            self._do_set_busy_ticks(2)
            self._img_cal = tuple(self._argbuf)
            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_CALIBRATE_IMAGE img_cal={self._img_cal}')
            return self._rx_queue.popleft()

        if op == self.OP_SET_DIO3_AS_TCXO_CTRL and len(self._argbuf) == 4:
            self._tcxo_voltage = self._argbuf[0]
            self._tcxo_timeout = (self._argbuf[1] << 16) | (self._argbuf[2] << 8) | self._argbuf[3]
            # pretend TCXO settles ⇒ XOSC ready
            self._clk32_ready = True
            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_SET_DIO3_AS_TCXO_CTRL voltage={self._tcxo_voltage} timeout={self._tcxo_timeout}')
            return self._rx_queue.popleft()

        if op == self.OP_SET_BUFFER_BASE_ADDR and len(self._argbuf) == 2:
            self._tx_base, self._rx_base = self._argbuf
            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_SET_BUFFER_BASE_ADDR tx_base={self._tx_base} rx_base={self._rx_base}')
            return self._rx_queue.popleft()

        # ---- Register access ----
        if op == self.OP_WRITE_REGISTER:
            if len(self._argbuf) == 2 and self._write_reg_addr is None:
                self._write_reg_addr = (self._argbuf[0] << 8) | self._argbuf[1]
                self._rx_queue.append(self._make_status())
                self._log_cmd(f'OP_WRITE_REGISTER 0x{self._write_reg_addr:04X}')
                return self._rx_queue.popleft()
            if self._write_reg_addr is not None and len(self._argbuf) >= 3:
                # all remaining bytes are data; write sequentially
                addr = self._write_reg_addr + (len(self._argbuf) - 3)
                self._regs[addr & 0xFFFF] = mosi_byte
                self._rx_queue.append(self._make_status())
                self._log_cmd(f'OP_WRITE_REGISTER 0x{self._write_reg_addr:04X} + {len(self._argbuf) - 3}')
                return self._rx_queue.popleft()

        if op == self.OP_READ_REGISTER:
            # format: 1D, addr_hi, addr_lo, then host clocks out bytes with NOPs;
            if len(self._argbuf) == 2 and self._read_reg_addr is None:
                self._read_reg_addr = (self._argbuf[0] << 8) | self._argbuf[1]
                # next byte returned after address phase is STATUS
                self._rx_queue.append(self._make_status())
                self._log_cmd(f'OP_READ_REGISTER 0x{self._read_reg_addr:04X}')
                return self._rx_queue.popleft()
            if self._read_reg_addr is not None and len(self._argbuf) >= 3:
                # for each NOP from host, return a data byte
                off = len(self._argbuf) - 3
                b = self._regs.get((self._read_reg_addr + off) & 0xFFFF, 0x00)
                self._rx_queue.append(b)
                self._log_cmd(f'OP_READ_REGISTER 0x{self._read_reg_addr:04X} + {off}')
                return self._rx_queue.popleft()

        # ---- FIFO/buffer access ----
        if op == self.OP_WRITE_BUFFER:
            if len(self._argbuf) == 1 and self._write_buf_off is None:
                self._write_buf_off = self._argbuf[0] & 0xFF
                self._rx_queue.append(self._make_status())
                self._log_cmd(f'OP_WRITE_BUFFER writeBufOff=0x{self._write_buf_off:02X}')
                return self._rx_queue.popleft()
            if self._write_buf_off is not None and len(self._argbuf) >= 2:
                idx = (self._write_buf_off + (len(self._argbuf) - 2)) & 0xFF
                self._fifo[idx] = mosi_byte
                self._rx_queue.append(self._make_status())
                self._log_cmd(f'OP_WRITE_BUFFER writeBufOff=0x{self._write_buf_off:02X} + {len(self._argbuf) - 2}')
                return self._rx_queue.popleft()

        if op == self.OP_READ_BUFFER:
            if len(self._argbuf) == 1 and self._read_buf_off is None:
                self._read_buf_off = self._argbuf[0] & 0xFF
                # return STATUS next
                self._rx_queue.append(self._make_status())
                self._log_cmd(f'OP_READ_BUFFER readBufOff=0x{self._read_buf_off:02X}')
                return self._rx_queue.popleft()
            if self._read_buf_off is not None and len(self._argbuf) >= 2:
                idx = (self._read_buf_off + (len(self._argbuf) - 2)) & 0xFF
                self._rx_queue.append(self._fifo[idx])
                self._log_cmd(f'OP_READ_BUFFER readBufOff=0x{self._read_buf_off:02X} + {len(self._argbuf) - 2}')
                return self._rx_queue.popleft()

        if op == self.OP_SET_DIO2_AS_RF_SWITCH_CTRL and len(self._argbuf) == 1:
            # DIO2 as RF switch control
            self._dio2_rf_switch_ctrl = self._argbuf[0] & 0xFF
            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_SET_DIO2_AS_RF_SWITCH_CTRL dio2RfSwitchCtrl=0x{self._dio2_rf_switch_ctrl:02X}')
            return self._rx_queue.popleft()

        if op == self.OP_SET_DIO_IRQ_PARAMS and len(self._argbuf) == 8:
            self._dio_irq_mask = self._argbuf[0] | (self._argbuf[1] << 8)
            self._dio1_mask = self._argbuf[2] | (self._argbuf[3] << 8)
            self._dio2_mask = self._argbuf[4] | (self._argbuf[5] << 8)
            self._dio3_mask = self._argbuf[6] | (self._argbuf[7] << 8)

            def m2s(m):
                if m == 0: return "0"
                names = [IRQ_BITS[b] for b in IRQ_BITS if (m & b)]
                return "|".join(names) if names else f"0x{m:04X}"

            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_SET_DIO_IRQ_PARAMS irqMask={m2s(self._dio_irq_mask)} '
                          f'dio1={m2s(self._dio1_mask)} dio2={m2s(self._dio2_mask)} dio3={m2s(self._dio3_mask)}')
            return self._rx_queue.popleft()

        if op == self.OP_SET_PA_CONFIG and len(self._argbuf) == 4:
            # SetPaConfig: 4-byte paDutyCycle, hpMax, deviceSel, paLut
            self._pa_duty_cycle = self._argbuf[0]
            self._hp_max = self._argbuf[1]
            self._device_sel = self._argbuf[2]
            self._pa_lut = self._argbuf[3]
            self._rx_queue.append(self._make_status())
            self._log_cmd(
                f'OP_SET_PA_CONFIG paDutyCycle={self._pa_duty_cycle}, hpMax={self._hp_max}, deviceSel={self._device_sel}, paLut={self._pa_lut}')
            return self._rx_queue.popleft()

        if op == self.OP_SET_TX_PARAMS and len(self._argbuf) == 2:
            # SetTxParams: 2-byte txPower, rampTime
            self._tx_power = self._argbuf[0]
            self._ramp_time = self._argbuf[1]
            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_SET_TX_PARAMS txPower={self._tx_power}, rampTime={self._ramp_time}')
            return self._rx_queue.popleft()

        if op == self.OP_SET_TX and len(self._argbuf) == 3:
            self._tx_timeout = (self._argbuf[0] << 16) | (self._argbuf[1] << 8) | self._argbuf[2]
            self._mode = self.MODE_TX
            self._do_set_busy_ticks(2)
            # naive: immediately mark TX_DONE (or Timeout if you'd like to emulate timeouts)
            self._irq_status |= 0x0002  # TX_DONE
            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_SET_TX timeout={self._tx_timeout}')
            return self._rx_queue.popleft()

        # ---- GetStatus ----
        if op == self.OP_GET_STATUS:
            # After opcode + 1 byte, we already returned status; any extra clocks just repeat status
            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_GET_STATUS mode={self._mode} clk32_ready={self._clk32_ready}')
            return self._rx_queue.popleft()

        # ---- SetRx: 0x82 timeout[23:0] ----
        if op == self.OP_SET_RX and len(self._argbuf) == 3:
            self._rx_timeout = (self._argbuf[0] << 16) | (self._argbuf[1] << 8) | self._argbuf[2]
            self._mode = self.MODE_RX
            # brief busy to emulate mode entry; real timing depends on TCXO/ramp, etc.
            self._do_set_busy_ticks(2)
            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_SET_RX timeout={self._rx_timeout}')
            return self._rx_queue.popleft()

        # ---- SetRfFrequency: 0x86 RfFreq(31:0) ----
        if op == self.OP_SET_RF_FREQUENCY and len(self._argbuf) == 4:
            self._rf_freq_word = ((self._argbuf[0] << 24) |
                                  (self._argbuf[1] << 16) |
                                  (self._argbuf[2] << 8) |
                                  self._argbuf[3])

            # The LSB of Freq is equal to the PLL step which is:
            # RFfrequency = Freq * Fstep
            # Where Fstep = 32 MHz / (2^25) = 32e6 / 33554432 = 0.9536743164 Hz
            # So RFfrequency (in Hz) = int(Freq) * 32e6 / 2^25
            freq_mhz = self._rf_freq_word * 0.9536743164 / 1e6
            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_SET_RF_FREQUENCY rfWord=0x{self._rf_freq_word:08X} ({freq_mhz:.6f} MHz)')
            self.result_cb("freq", f"{freq_mhz:.6f}")
            return self._rx_queue.popleft()

        # ---- SetPacketType: 0x8A PacketType ----
        if op == self.OP_SET_PACKET_TYPE and len(self._argbuf) == 1:
            self._packet_type = self._argbuf[0] & 0x01  # 0=GFSK, 1=LoRa
            self._rx_queue.append(self._make_status())
            packet_type_str = "GFSK" if self._packet_type == 0 else "LoRa"
            self._log_cmd(f'OP_SET_PACKET_TYPE type={self._packet_type} ("{packet_type_str}")')
            return self._rx_queue.popleft()

        # ---- SetModulationParams: 0x8B 8 bytes ----
        if op == self.OP_SET_MODULATION_PARAMS and len(self._argbuf) == self._need_args:
            self._mod_params = list(self._argbuf[:8])
            self._rx_queue.append(self._make_status())
            description = []
            if self._packet_type == 1:
                sf = self._mod_params[0] & 0x0F
                if sf in SF_DESC:
                    description.append(f'SF={SF_DESC[sf]}')
                    self.result_cb("sf", sf)
                bw = self._mod_params[1] & 0x0F
                if bw in BW_DESC:
                    description.append(f'BW={BW_DESC[bw]}')
                    self.result_cb("bw", BW_DESC[bw])
                cr = (self._mod_params[2]) & 0x07
                if cr in CR_DESC:
                    description.append(f'CR={CR_DESC[cr]}')
                    self.result_cb("cr", CR_DESC[cr])
            description = ",".join(description)
            self._log_cmd(f'OP_SET_MODULATION_PARAMS {self._mod_params} ({description})')
            return self._rx_queue.popleft()

        # ---- SetPacketParams: 0x8C 9 bytes ----
        if op == self.OP_SET_PACKET_PARAMS and len(self._argbuf) == self._need_args:
            if self._packet_type == 1:
                # LoRa (6 bytes): [preLenHi, preLenLo, headerType, payloadLen, crcType, invertIQ]
                preamble = (self._argbuf[0] << 8) | self._argbuf[1]
                header_type = self._argbuf[2] & 0x01
                payload_len = self._argbuf[3] & 0xFF
                crc_on = (self._argbuf[4] & 0x01) == 1
                invert_iq = (self._argbuf[5] & 0x01) == 1

                self._lora_pkt = {
                    "preamble_symbols": preamble,
                    "header_type": header_type,  # 0 explicit, 1 implicit
                    "payload_len": payload_len,  # bytes
                    "crc_on": crc_on,  # bool
                    "invert_iq": invert_iq  # bool
                }
                desc = (f"LoRa: preamble={preamble},"
                        f" header={'explicit (Variable length packet)' if header_type == 0 else 'implicit(Fixed length packet)'},"
                        f" payloadLen={payload_len},"
                        f" CRC={'ON' if crc_on else 'OFF'},"
                        f" IQ={'inverted' if invert_iq else 'standard'}")
                self._pkt_params = list(self._argbuf[:6])  # keep last raw payload for inspection
                self.result_cb("preamble", preamble)
                self.result_cb("header_type", "explicit" if header_type == 0 else "implicit")
                self.result_cb("payload_len", payload_len)
                self.result_cb("crc", "on" if crc_on else "off")
                self.result_cb("iq", "inverted" if invert_iq else "standard")
            else:
                # GFSK (9 bytes):
                # [preLenHi, preLenLo, preDetLen, syncLen, addrComp, pktType, payloadLen, crcType, whitening]
                preamble_bits = (self._argbuf[0] << 8) | self._argbuf[1]
                pre_det = self._argbuf[2] & 0xFF
                sync_len_bits = self._argbuf[3] & 0xFF
                addr_comp = self._argbuf[4] & 0x03
                pkt_type = self._argbuf[5] & 0x01  # 0=fixed, 1=variable
                payload_len = self._argbuf[6] & 0xFF
                crc_type = self._argbuf[7] & 0xFF
                whitening = self._argbuf[8] & 0x01

                self._gfsk_pkt = {
                    "preamble_bits": preamble_bits,
                    "preamble_detector": pre_det,
                    "sync_len_bits": sync_len_bits,
                    "addr_filter": addr_comp,
                    "packet_type": pkt_type,
                    "payload_len": payload_len,
                    "crc_type": crc_type,
                    "whitening": whitening
                }
                desc = (f"GFSK: preamble={preamble_bits}b, preDet=0x{pre_det:02X},"
                        f" syncLen={sync_len_bits}b, addrComp={addr_comp},"
                        f" pktType={'variable' if pkt_type else 'fixed'},"
                        f" payloadLen={payload_len}, crcType=0x{crc_type:02X},"
                        f" whitening={'ON' if whitening else 'OFF'}")
                self._pkt_params = list(self._argbuf[:9])

            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_SET_PACKET_PARAMS {desc}')
            return self._rx_queue.popleft()

        # ---- SetRxTxFallbackMode: 0x93 ----
        if op == self.OP_SET_RXTX_FALLBACK_MODE and len(self._argbuf) == 1:
            self._fallback_mode = self._argbuf[0] & 0xFF
            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_SET_RXTX_FALLBACK_MODE mode=0x{self._fallback_mode:02X}')
            return self._rx_queue.popleft()

        # ---- StopTimerOnPreamble: 0x9F ----
        if op == self.OP_STOP_TIMER_ON_PREAMBLE and len(self._argbuf) == 1:
            self._stop_on_preamble = self._argbuf[0] & 0x01
            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_STOP_TIMER_ON_PREAMBLE stopOnPreamble={self._stop_on_preamble}')
            return self._rx_queue.popleft()

        # ---- SetLoRaSymbNumTimeout: 0xA0 ----
        if op == self.OP_SET_LORA_SYMB_NUM_TIMEOUT and len(self._argbuf) == 1:
            self._lora_symb_timeout = self._argbuf[0] & 0xFF
            self._rx_queue.append(self._make_status())
            self._log_cmd(f'OP_SET_LORA_SYMB_NUM_TIMEOUT symbNum={self._lora_symb_timeout}')
            return self._rx_queue.popleft()

        # ---- Unknown opcode or unhandled case ----
        if op not in self.existing_ops:
            self._log_cmd(f"OP_UNKNOWN 0x{op:02X} with {len(self._argbuf)} args")
        # default: echo 0 if nothing was queued
        return 0x00

    # ------------------ helpers ------------------
    def _make_status(self):
        # Status byte: [7]=RFU, [6:4]=chip mode, [3:1]=cmd status (we keep 0b001 “data available” clear; use 0b001 as OK)
        cmd_status = 0x1
        if getattr(self, "_last_cmd_error", False):
            cmd_status = 0x4  # processing error
            self._last_cmd_error = False
        st = ((self._mode & 0x7) << 4) | ((cmd_status & 0x7) << 1)
        return st & 0xFF

    def _do_set_busy_ticks(self, ticks):
        # Simple “busy” simulation; host will poll LORAC_SR and see BUSY_DIG bit high meanwhile.
        self._busy = max(self._busy, ticks)

    def tick(self):
        if self._busy > 0:
            self._busy -= 1

    def reset(self):
        self._mode = self.MODE_STBY_RC
        self._clk32_ready = False
        self._reg_mode = 0  # LDO by default
        self._busy = 0
        self._regs = {}  # 16-bit address space → byte
        self._fifo = bytearray(256)
        self._tx_base = 0
        self._rx_base = 0
        self._rx_queue = deque()
        self._opcode = None
        self._argbuf = []
        self._read_count_left = None
        self._read_source = None
        self._tx_stream_index = 0
        self._pending_status_after = 0
        self._write_reg_addr = None
        self._read_reg_addr = None
        self._write_buf_off = None
        self._read_buf_off = None
        self._last_cmd_error = False

        self._rf_freq_word = 0  # raw 32-bit PLL word of SetRfFrequency
        self._packet_type = 0  # 0=GFSK, 1=LoRa
        self._mod_params = [0] * 8  # last SetModulationParams payload
        self._pkt_params = [0] * 9  # last SetPacketParams payload
        self._fallback_mode = 0
        self._stop_on_preamble = 0
        self._lora_symb_timeout = 0
        self._rx_timeout = 0  # last SetRx timeout (24-bit ticks)

        self._irq_status = 0
        self._dio1_mask = 0
        self._dio2_mask = 0
        self._dio3_mask = 0
        self._last_rx = {"len": 0, "off": 0}
        self._lora_link = {"rssi": -70, "snr": 7, "signal_rssi": -73}  # tweak to taste
        self._cad = {"num_sym": 1, "det_peak": 0x14, "det_min": 0x0A, "exit_mode": 0, "timeout": 0}

    def _log_cmd(self, val):
        if self.cmd_cb:
            self.cmd_cb(val)


# -------------------- LoRaCDevice (with SPI + SR wiring) --------------------

class LoRaCDevice:
    BASE = 0x40009000
    SIZE = 0x1000

    # Offsets (from ASR6601 RM)
    SSP_CR0 = 0x000
    SSP_CR1 = 0x004
    SSP_DR = 0x008
    SSP_SR = 0x00C
    SSP_CPSR = 0x010
    SSP_IMSC = 0x014
    SSP_RIS = 0x018
    SSP_MIS = 0x01C
    SSP_ICR = 0x020
    SSP_DMACR = 0x024

    LORAC_CR0 = 0x100
    LORAC_CR1 = 0x104  # reset 0x00000080
    LORAC_SR = 0x108  # bit8 BUSY_DIG_SR, bit1 CLK_32M_RDY_BAT_SR
    LORAC_NSS_CR = 0x10C
    LORAC_SCK_CR = 0x110
    LORAC_MOSI_CR = 0x114
    LORAC_MISO_SR = 0x118

    SR_BUSY_DIG = 1 << 8
    SR_CLK32_RDY = 1 << 1
    NSS_REG_BIT = 1 << 0

    SSP_SR_TFE = 1 << 0
    SSP_SR_TNF = 1 << 1
    SSP_SR_RNE = 1 << 2
    SSP_SR_BUSY = 1 << 4

    def __init__(self, base=BASE, **kwargs):
        kwargs = kwargs or {}
        dprint = kwargs.get("dprint", lambda *a, **k: None)
        cmd_cb = kwargs.get("cmd_cb", lambda *a, **k: None)
        result_cb = kwargs.get("result_cb", lambda *a, **k: None)
        self.base = base
        self.dprint = dprint
        self.cmd_cb = cmd_cb

        # Replace echo backend with SX126x stub
        self.rf = Sx126xStub(dprint=dprint, cmd_cb=cmd_cb, result_cb=result_cb)

        self.reg = {}
        # Reset defaults
        self._w32(self.LORAC_CR1, 0x00000080)  # POR_BAT=1
        self._w32(self.LORAC_SR, self.SR_BUSY_DIG)  # start busy; cleared by CR1 sequence
        self._w32(self.LORAC_NSS_CR, self.NSS_REG_BIT)  # NSS high (idle)
        # SSP defaults
        self._w32(self.SSP_CR0, 0)
        self._w32(self.SSP_CR1, 0)
        self._w32(self.SSP_CPSR, 2)
        self._w32(self.SSP_IMSC, 0)
        self._w32(self.SSP_RIS, 0)
        self._w32(self.SSP_MIS, 0)
        self._w32(self.SSP_ICR, 0)
        self._w32(self.SSP_DMACR, 0)
        self._w32(self.SSP_SR, self.SSP_SR_TFE | self.SSP_SR_TNF)

        self.tx_fifo = deque()
        self.rx_fifo = deque()
        self.in_transaction = False

    # ------- Unicorn integration API -------
    def handles(self, addr):
        return self.base <= addr < (self.base + self.SIZE)

    def read(self, uc, addr, size):
        off = addr - self.base

        # tick the RF “busy” countdown once per register read to eventually clear BUSY
        self._sync_lorac_status()

        if off == self.SSP_DR:
            return self._ssp_dr_read()
        if off == self.LORAC_MISO_SR:
            # We don't emulate MISO pin level; return 0.
            return 0
        if off == self.LORAC_SR:
            return self.reg.get(off, 0)
        return self.reg.get(off, 0)

    def write(self, uc, addr, size, value):
        off = addr - self.base
        val32 = value & 0xFFFFFFFF

        # Mirror BUSY + CLK32_RDY into LORAC_SR continuously
        def latch_sr():
            sr = 0
            if self.rf.busy:
                sr |= self.SR_BUSY_DIG
            if self.rf.clk32_ready:
                sr |= self.SR_CLK32_RDY
            self._w32(self.LORAC_SR, sr)

        if off == self.LORAC_CR1:
            self._w32(off, val32)
            self._handle_cr1_change(val32)
            latch_sr()
            return True

        if off == self.LORAC_NSS_CR:
            old = self.reg.get(off, 0)
            self._w32(off, val32)
            was_high = bool(old & self.NSS_REG_BIT)
            now_high = bool(val32 & self.NSS_REG_BIT)
            if was_high and not now_high:
                self._start_xfer()
            elif not was_high and now_high:
                self._end_xfer()
            latch_sr()
            return True

        if off == self.SSP_DR:
            self._ssp_dr_write(val32, size)
            latch_sr()
            return True

        if off == self.SSP_ICR:
            self._w32(self.SSP_RIS, 0)
            self._w32(self.SSP_MIS, 0)
            return True

        self._w32(off, val32)
        return True

    # ------- Internals -------
    def _w32(self, off, val):
        self.reg[off] = val & 0xFFFFFFFF

    def _set_sr_bits(self, set_mask=0, clr_mask=0):
        sr = self.reg.get(self.SSP_SR, 0)
        sr = (sr | set_mask) & ~clr_mask
        self._w32(self.SSP_SR, sr)

    def _recalc_ssp_sr(self, busy=False):
        sr = 0
        # TX FIFO empty?
        if len(self.tx_fifo) == 0:
            sr |= self.SSP_SR_TFE
        # TX not full (we don't model depth → always not full)
        sr |= self.SSP_SR_TNF
        # RX FIFO not empty?
        if len(self.rx_fifo) > 0:
            sr |= self.SSP_SR_RNE
        # Busy?
        if busy:
            sr |= self.SSP_SR_BUSY
        self._w32(self.SSP_SR, sr)

    def _ssp_dr_write(self, val32, size):
        byte = val32 & 0xFF
        # print(f'{byte:02x}', end=' ')
        # append as new line to file lora.log
        # with open('lora.log', 'a') as f:
        #     f.write(f'{byte:02x}\n')
        # If we are in a transaction, we will shift the byte out immediately.

        # Push one byte into TX FIFO → not empty → TFE=0 during the shift
        self.tx_fifo.append(byte)
        self._recalc_ssp_sr(busy=True)

        if self.in_transaction:
            miso = self.rf.shift(byte)  # one SPI byte exchanged
            self.rx_fifo.append(miso)

        # After immediate “transfer”, TX FIFO is effectively consumed
        self.tx_fifo.clear()
        # Recompute SR: RX may have data (RNE=1), TX empty (TFE=1), not busy
        self._recalc_ssp_sr(busy=False)

    def _ssp_dr_read(self):
        if self.rx_fifo:
            b = self.rx_fifo.popleft()
            # Recompute SR because RNE might change
            self._recalc_ssp_sr(busy=False)
            return b
        self._recalc_ssp_sr(busy=False)
        return 0

    def _start_xfer(self):
        self.dprint("[LoRaC] NSS=0 (select)")
        self.in_transaction = True
        self.tx_fifo.clear()
        self.rx_fifo.clear()
        self.rf.start()
        self._sync_lorac_status()

    def _end_xfer(self):
        self.dprint("[LoRaC] NSS=1 (de-select)")
        self.in_transaction = False
        self.rf.end()
        self._sync_lorac_status()

    def _sync_lorac_status(self):
        # one “tick” brings us closer to BUSY low
        self.rf.tick()
        sr = 0
        if self.rf.busy:
            sr |= self.SR_BUSY_DIG
        if self.rf.clk32_ready:
            sr |= self.SR_CLK32_RDY
        self._w32(self.LORAC_SR, sr)

    def _handle_cr1_change(self, cr1):
        # POR_BAT (bit7), NRESET_BAT (bit5), CLK_32M_EN_BAT (bit2), TCXO_EN_BAT (bit1)
        por = (cr1 >> 7) & 1
        nreset = (cr1 >> 5) & 1
        clk_en = (cr1 >> 2) & 1
        tcxo_en = (cr1 >> 1) & 1

        # simple model: when POR=0 and NRESET=1 → not busy; when enabling CLK32 or TCXO, mark CLK ready
        if nreset and not por:
            # leave BUSY low; clock ready follows TCXO/CLK enable
            self.rf._busy = 0
        else:
            self.rf._busy = max(self.rf._busy, 1)

        if clk_en or tcxo_en:
            self.rf._clk32_ready = True
        else:
            # don’t aggressively clear; once ready, keep it (fits common init flows)
            pass

        self.dprint(f"[LoRaC] CR1 write: POR={por} NRESET={nreset} CLK_EN={clk_en} TCXO_EN={tcxo_en}")
