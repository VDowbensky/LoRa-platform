#!/usr/bin/env python3

import argparse
import ctypes
import pathlib
import struct

from unicorn import *
from unicorn.arm_const import *

from emulator_utils import _write_mmio_value, get_block_by_addr
from lora_device import LoRaCDevice
from uart_device import UartDevice, UART0_BASE


# struct efc_t
# {
#   unsigned int CR;                      ///< control register, offset 0x0
#   unsigned int INT_EN;                  ///< interrupt enable register, offset 0x4
#   unsigned int SR;                      ///< status register, offset 0x8
#   unsigned int PROGRAM_DATA0;           ///< program data0 register, offset 0xC
#   unsigned int PROGRAM_DATA1;           ///< program data1 register, offset 0x10
#   unsigned int TIMING_CFG;              ///< timing config register, offset 0x14
#   volatile unsigned int PROTECT_SEQ;    ///< protect sequence register, offset 0x18
#   unsigned int RSV0;                    ///< reserved, offset 0x1C
#   unsigned int CHIP_PATTERN;            ///< chip pattern register, offset 0x20
#   unsigned int IP_TRIM_L;               ///< analog ip trimming low register, offset 0x24
#   unsigned int IP_TRIM_H;               ///< analog ip trimming high register, offset 0x28
#   unsigned int SN_L;                    ///< serial number low register, offset 0x2C
#   unsigned int SN_H;                    ///< serial number high register, offset 0x30
#   unsigned int TEST_INFO_L;             ///< test info low register, offset 0x34
#   unsigned int TEST_INFO_H;             ///< test info high register, offset 0x38
#   unsigned int OPTION_CSR_BYTES;        ///< option control and status register, offset 0x3C
#   unsigned int OPTION_EO_BYTES;         ///< option exe-only bytes register, offset 0x40
#   unsigned int OPTION_WP_BYTES;         ///< option write-protect bytes register, offset 0x44
#   unsigned int OPTION_SEC_BYTES0;       ///< option secure byte 0 register, offset 0x48
#   unsigned int OPTION_SEC_BYTES1;       ///< option secure byte 1 register, offset 0x4C
# };
class EFC(ctypes.LittleEndianStructure):
    BASE = 0x40020000
    _fields_ = (
        ("CR", ctypes.c_uint32),
        ("INT_EN", ctypes.c_uint32),
        ("SR", ctypes.c_uint32),
        ("PROGRAM_DATA0", ctypes.c_uint32),
        ("PROGRAM_DATA1", ctypes.c_uint32),
        ("TIMING_CFG", ctypes.c_uint32),
        ("PROTECT_SEQ", ctypes.c_uint32),
        ("RSV0", ctypes.c_uint32),
        ("CHIP_PATTERN", ctypes.c_uint32),
        ("IP_TRIM_L", ctypes.c_uint32),
        ("IP_TRIM_H", ctypes.c_uint32),
        ("SN_L", ctypes.c_uint32),
        ("SN_H", ctypes.c_uint32),
        ("TEST_INFO_L", ctypes.c_uint32),
        ("TEST_INFO_H", ctypes.c_uint32),
        ("OPTION_CSR_BYTES", ctypes.c_uint32),
        ("OPTION_EO_BYTES", ctypes.c_uint32),
        ("OPTION_WP_BYTES", ctypes.c_uint32),
        ("OPTION_SEC_BYTES0", ctypes.c_uint32),
        ("OPTION_SEC_BYTES1", ctypes.c_uint32),
    )


# /// \brief  Structure type to access the System Control Block (SCB).
# struct SCB_t
# {
#   unsigned int CPUID;                   ///< Offset: 0x000 (R/ )  CPUID Base Register
#   unsigned int ICSR;                    ///< Offset: 0x004 (R/W)  Interrupt Control and State Register
#   unsigned int VTOR;                    ///< Offset: 0x008 (R/W)  Vector Table Offset Register
#   unsigned int AIRCR;                   ///< Offset: 0x00C (R/W)  Application Interrupt and Reset Control Register
#   unsigned int SCR;                     ///< Offset: 0x010 (R/W)  System Control Register
#   unsigned int CCR;                     ///< Offset: 0x014 (R/W)  Configuration Control Register
#   unsigned int SHP[12];                 ///< Offset: 0x018 (R/W)  System Handlers Priority Registers (4-7, 8-11, 12-15)
#   unsigned int SHCSR;                   ///< Offset: 0x024 (R/W)  System Handler Control and State Register
#   unsigned int CFSR;                    ///< Offset: 0x028 (R/W)  Configurable Fault Status Register
#   unsigned int HFSR;                    ///< Offset: 0x02C (R/W)  HardFault Status Register
#   unsigned int DFSR;                    ///< Offset: 0x030 (R/W)  Debug Fault Status Register
#   unsigned int MMFAR;                   ///< Offset: 0x034 (R/W)  MemManage Fault Address Register
#   unsigned int BFAR;                    ///< Offset: 0x038 (R/W)  BusFault Address Register
#   unsigned int AFSR;                    ///< Offset: 0x03C (R/W)  Auxiliary Fault Status Register
#   unsigned int PFR[2];                  ///< Offset: 0x040 (R/ )  Processor Feature Register
#   unsigned int DFR;                     ///< Offset: 0x048 (R/ )  Debug Feature Register
#   unsigned int ADR;                     ///< Offset: 0x04C (R/ )  Auxiliary Feature Register
#   unsigned int MMFR[4];                 ///< Offset: 0x050 (R/ )  Memory Model Feature Register
#   unsigned int ISAR[5];                 ///< Offset: 0x060 (R/ )  Instruction Set Attributes Register
#   unsigned int RESERVED0[5];
#   unsigned int CPACR;                   ///< Offset: 0x088 (R/W)  Coprocessor Access Control Register
# };
class SCB(ctypes.LittleEndianStructure):
    BASE = 0xe000ed00
    _fields_ = (
        ("CPUID", ctypes.c_uint32),
        ("ICSR", ctypes.c_uint32),
        ("VTOR", ctypes.c_uint32),
        ("AIRCR", ctypes.c_uint32),
        ("SCR", ctypes.c_uint32),
        ("CCR", ctypes.c_uint32),
        ("SHP", ctypes.c_uint32 * 12),
        ("SHCSR", ctypes.c_uint32),
        ("CFSR", ctypes.c_uint32),
        ("HFSR", ctypes.c_uint32),
        ("DFSR", ctypes.c_uint32),
        ("MMFAR", ctypes.c_uint32),
        ("BFAR", ctypes.c_uint32),
        ("AFSR", ctypes.c_uint32),
        ("PFR", ctypes.c_uint32 * 2),
        ("DFR", ctypes.c_uint32),
        ("ADR", ctypes.c_uint32),
        ("MMFR", ctypes.c_uint32 * 4),
        ("ISAR", ctypes.c_uint32 * 5),
        ("RESERVED0", ctypes.c_uint32 * 5),
        ("CPACR", ctypes.c_uint32),
    )


# struct lorac_t
# {
#   unsigned int SSP_CR0;                 ///< ssp control register 0, offset 0x0
#   unsigned int SSP_CR1;                 ///< ssp control register 1, offset 0x4
#   unsigned int SSP_DR;                  ///< ssp data register, offset 0x8
#   unsigned int SSP_SR;                  ///< ssp status register, offset 0xC
#   unsigned int SSP_CPSR;                ///< ssp clock prescale register, offset 0x10
#   unsigned int SSP_IMSC;                ///< ssp interrupt mask set or clear register, offset 0x14
#   unsigned int SSP_RIS;                 ///< ssp raw interrupt status register, offset 0x18
#   unsigned int SSP_MIS;                 ///< ssp masked interrupt status register, offset 0x1C
#   unsigned int SSP_ICR;                 ///< ssp interrupt clear register, offset 0x20
#   unsigned int SSP_DMA_CR;              ///< ssp DMA control register, offset 0x24
#   unsigned int RESV[54];                ///< reserved, offset 0x28-0xFC
#   unsigned int CR0;                     ///< control register 0, offset 0x100
#   unsigned int CR1;                     ///< control register 1, offset 0x104
#   unsigned int SR;                      ///< status register, offset 0x108
#   unsigned int NSS_CR;                  ///< nss control register, offset 0x10C
#   unsigned int SCK_CR;                  ///< sck control register, offset 0x110
#   unsigned int MOSI_CR;                 ///< mosi control register, offset 0x114
#   unsigned int MISO_SR;                 ///< miso control register, offset 0x118
# };
class LORAC(ctypes.LittleEndianStructure):
    BASE = 0x40009000
    _fields_ = (
        ("SSP_CR0", ctypes.c_uint32),
        ("SSP_CR1", ctypes.c_uint32),
        ("SSP_DR", ctypes.c_uint32),
        ("SSP_SR", ctypes.c_uint32),
        ("SSP_CPSR", ctypes.c_uint32),
        ("SSP_IMSC", ctypes.c_uint32),
        ("SSP_RIS", ctypes.c_uint32),
        ("SSP_MIS", ctypes.c_uint32),
        ("SSP_ICR", ctypes.c_uint32),
        ("SSP_DMA_CR", ctypes.c_uint32),
        ("RESV", ctypes.c_uint32 * 54),
        ("CR0", ctypes.c_uint32),
        ("CR1", ctypes.c_uint32),
        ("SR", ctypes.c_uint32),
        ("NSS_CR", ctypes.c_uint32),
        ("SCK_CR", ctypes.c_uint32),
        ("MOSI_CR", ctypes.c_uint32),
        ("MISO_SR", ctypes.c_uint32),
    )


# struct rcc_t
# {
#   unsigned int CR0;                     ///< control register 0
#   unsigned int CR1;                     ///< control register 1
#   unsigned int CR2;                     ///< control register 2
#   unsigned int CGR0;                    ///< clock generation register 0
#   unsigned int CGR1;                    ///< clock generation register 1
#   unsigned int CGR2;                    ///< clock generation register 2
#   unsigned int RST0;                    ///< reset register 0
#   unsigned int RST1;                    ///< reset register 1
#   unsigned int RST_SR;                  ///< reset status register 0
#   unsigned int RST_CR;                  ///< reset control register 0
#   unsigned int SR;                      ///< status register
#   unsigned int SR1;                     ///< status register 1
#   unsigned int CR3;                     ///< control register 3
# };
class RCC(ctypes.LittleEndianStructure):
    BASE = 0x40000000
    _fields_ = (
        ("CR0", ctypes.c_uint32),
        ("CR1", ctypes.c_uint32),
        ("CR2", ctypes.c_uint32),
        ("CGR0", ctypes.c_uint32),
        ("CGR1", ctypes.c_uint32),
        ("CGR2", ctypes.c_uint32),
        ("RST0", ctypes.c_uint32),
        ("RST1", ctypes.c_uint32),
        ("RST_SR", ctypes.c_uint32),
        ("RST_CR", ctypes.c_uint32),
        ("SR", ctypes.c_uint32),
        ("SR1", ctypes.c_uint32),
        ("CR3", ctypes.c_uint32),
    )


# struct iwdg_t
# {
#   unsigned int CR;                      ///< control register, offset 0x0
#   unsigned int MAX;                     ///< max value register, offset 0x4
#   unsigned int WIN;                     ///< window value register, offset 0x8
#   unsigned int SR;                      ///< status register, offset 0xC
#   unsigned int SR1;                     ///< status register 1, offset 0x10
#   unsigned int CR1;                     ///< control register 1, offset 0x14
#   unsigned int SR2;                     ///< status register 2, offset 0x18
# };
class IWDG(ctypes.LittleEndianStructure):
    BASE = 0x4001d000
    _fields_ = (
        ("CR", ctypes.c_uint32),
        ("MAX", ctypes.c_uint32),
        ("WIN", ctypes.c_uint32),
        ("SR", ctypes.c_uint32),
        ("SR1", ctypes.c_uint32),
        ("CR1", ctypes.c_uint32),
        ("SR2", ctypes.c_uint32),
    )


# struct lptimer_t
# {
#   unsigned int ISR;                     ///< LPTIMER flag and status register
#   unsigned int ICR;                     ///< LPTIMER flag clear register
#   unsigned int IER;                     ///< LPTIMER interrupt enable register
#   unsigned int CFGR;                    ///< LPTIMER configuration register
#   unsigned int CR;                      ///< LPTIMER control register
#   unsigned int CMP;                     ///< LPTIMER compare register
#   unsigned int ARR;                     ///< LPTIMER autoreload register
#   unsigned int CNT;                     ///< LPTIMER counter register
#   unsigned int CSR;                     ///< LPTIMER CSR register
#   unsigned int SR1;                     ///< LPTIMER SR1 register
# };
class LPTIMER(ctypes.LittleEndianStructure):
    BASE = None
    _fields_ = (
        ("ISR", ctypes.c_uint32),
        ("ICR", ctypes.c_uint32),
        ("IER", ctypes.c_uint32),
        ("CFGR", ctypes.c_uint32),
        ("CR", ctypes.c_uint32),
        ("CMP", ctypes.c_uint32),
        ("ARR", ctypes.c_uint32),
        ("CNT", ctypes.c_uint32),
        ("CSR", ctypes.c_uint32),
        ("SR1", ctypes.c_uint32),
    )


class LPTIMER0(LPTIMER):
    BASE = 0x4000d000


# struct gpio_t
# {
#   unsigned int OER;                     ///< output enable register
#   unsigned int OTYPER;                  ///< output type register
#   unsigned int IER;                     ///< input enable register
#   unsigned int PER;                     ///< pull enable register
#   unsigned int PSR;                     ///< pull select register
#   unsigned int IDR;                     ///< input data register
#   unsigned int ODR;                     ///< output data register
#   unsigned int BRR;                     ///< bit reset register
#   unsigned int BSR;                     ///< bit set register
#   unsigned int DSR;                     ///< dirve set register
#   unsigned int ICR;                     ///< interrupt control register
#   unsigned int IFR;                     ///< interrupt flag register
#   unsigned int WUCR;                    ///< wakeup control register
#   unsigned int WULVL;                   ///< wakeup level register
#   unsigned int AFRL;                    ///< alternate function low register
#   unsigned int AFRH;                    ///< alternate function high register
#   unsigned int STOP3_WUCR;              ///< stop3 wakeup control register
# };
class GPIO(ctypes.LittleEndianStructure):
    BASE = None
    _fields_ = (
        ("OER", ctypes.c_uint32),
        ("OTYPER", ctypes.c_uint32),
        ("IER", ctypes.c_uint32),
        ("PER", ctypes.c_uint32),
        ("PSR", ctypes.c_uint32),
        ("IDR", ctypes.c_uint32),
        ("ODR", ctypes.c_uint32),
        ("BRR", ctypes.c_uint32),
        ("BSR", ctypes.c_uint32),
        ("DSR", ctypes.c_uint32),
        ("ICR", ctypes.c_uint32),
        ("IFR", ctypes.c_uint32),
        ("WUCR", ctypes.c_uint32),
        ("WULVL", ctypes.c_uint32),
        ("AFRL", ctypes.c_uint32),
        ("AFRH", ctypes.c_uint32),
        ("STOP3_WUCR", ctypes.c_uint32),
    )


class GPIOA(GPIO):
    BASE = 0x4001f000


def dump_registers(mu: Uc):
    for i in range(13):
        register = globals()[f"UC_ARM_REG_R{i}"]
        print(f"r{i} = {mu.reg_read(register):#010x}".rjust(18), end="" if (i + 1) % 4 else "\n")
    print(f"sp = {mu.reg_read(UC_ARM_REG_SP):#010x}".rjust(18), end="")
    print(f"lr = {mu.reg_read(UC_ARM_REG_LR):#010x}".rjust(18), end="")
    print(f"pc = {mu.reg_read(UC_ARM_REG_PC):#010x}".rjust(18))


# base, size
ROM = 0x08000000, 0x20000
SRAM = 0x20000000, 0x4000
IO = 0x40000000, 0x10000000
SYS_IO = 0xe0000000, 0x100000

FIRMWARE_BASE = 0x08004000  # skipping the bootloader

CONTEXT = [globals()[f"UC_ARM_REG_R{i}"] for i in range(13)] + \
          [UC_ARM_REG_SP, UC_ARM_REG_LR, UC_ARM_REG_PC, UC_ARM_REG_CPSR]


def emulate(data, bind, debug=False):
    def dprint(*args, **kwargs):
        print(*args, **kwargs) if debug else None

    uart_buffer = []

    def tx_sink(b):
        uart_buffer.append(b)  # you already print this at the end

    uart0 = UartDevice(UART0_BASE, tx_cb=tx_sink, dprint=dprint)

    lora_results = {}

    def lora_result(key, val):
        if key in lora_results:
            dprint(f"[LoRa] Overwriting result for {key}: {lora_results[key]} -> {val}")
        lora_results[key] = val
        dprint(f"[LoRa] Result for {key}: {val}")

    lora_cmds = []

    def lora_sink(data):
        lora_cmds.append(data)

    lora = LoRaCDevice(dprint=dprint, cmd_cb=lora_sink, result_cb=lora_result)

    devices = [
        uart0,
        lora,
    ]

    def hook_write(uc, access, addr, size, value, user_data):
        # if address == LORAC.BASE + LORAC.SSP_DR.offset:
        #     print(f"{value:02x}")

        for dev in devices:
            if dev.handles(addr):
                return dev.write(uc, addr, size, value)

        return False  # allow other writes

    def read_hook(uc, access, addr, size, value, _):
        # delegate to devices
        for dev in devices:
            if dev.handles(addr):
                val = dev.read(uc, addr, size)
                _write_mmio_value(uc, addr, size, val)
                blk = get_block_by_addr(addr)
                dprint(f"[HOOK] {blk} read 0x{addr:X} -> 0x{val:08X}")
                return True, val

        dprint(f"[HOOK] read_hook at 0x{addr:X}, size={size}, value={value:#x}")
        return False, 0

    uc = Uc(UC_ARCH_ARM, UC_MODE_THUMB)
    for base, size in ROM, SRAM, IO, SYS_IO:
        uc.mem_map(base, size)
    rom_base, _ = ROM
    uc.mem_write(rom_base, data)
    sp, reset = struct.unpack_from("<2I", data, FIRMWARE_BASE - rom_base)
    sys_tick = struct.unpack_from("<I", data, FIRMWARE_BASE - rom_base + 0x3c)[0]
    efc = EFC()
    efc.SR = 2
    uc.mem_write(efc.BASE, bytes(efc))
    scb = SCB()
    scb.VTOR = 0x08000000
    uc.mem_write(scb.BASE, bytes(scb))
    lorac = LORAC()
    lorac.SR = 2
    lorac.SSP_SR = 1
    uc.mem_write(lorac.BASE, bytes(lorac))
    rcc = RCC()
    rcc.SR = 0x3f
    uc.mem_write(rcc.BASE, bytes(rcc))
    iwdg = IWDG()
    iwdg.SR = 0xf
    uc.mem_write(iwdg.BASE, bytes(iwdg))
    lptimer0 = LPTIMER0()
    lptimer0.ISR = 0x198
    uc.mem_write(lptimer0.BASE, bytes(lptimer0))
    if not bind:
        gpioa = GPIOA()
        gpioa.IDR = 1 << 0xf
        uc.mem_write(gpioa.BASE, bytes(gpioa))
    uc.hook_add(UC_HOOK_MEM_WRITE, hook_write)

    uc.reg_write(UC_ARM_REG_SP, sp)
    main_context = dict(zip(CONTEXT, uc.reg_read_batch(CONTEXT)))
    main_context[UC_ARM_REG_PC] = reset
    sys_tick_context = dict(zip(CONTEXT, uc.reg_read_batch(CONTEXT)))
    for _ in range(1000):  # ~1s of emulation time
        uc.reg_write_batch(tuple(sys_tick_context.items()))
        uc.emu_start(sys_tick, 0)  # no need to save this context
        uc.reg_write_batch(tuple(main_context.items()))
        uc.emu_start(main_context[UC_ARM_REG_PC] | 1, 0, count=1000)  # 1ms
        main_context = dict(zip(CONTEXT, uc.reg_read_batch(CONTEXT)))

    return {
        "lora_results": lora_results,
        "uart_buffer": uart_buffer,
        "lora_cmds": lora_cmds,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("path", type=pathlib.Path, help="Path to the firmware dump")
    parser.add_argument("--bind", action="store_true", help="Trigger bind configuration")
    args = parser.parse_args()

    data = args.path.read_bytes()
    result = emulate(data, args.bind, debug=True)
    print("[*] Emulation completed.")
    uart_buf = result["uart_buffer"]
    if uart_buf:
        print(f"[*] UART buffer (length={len(uart_buf)}): {''.join(chr(c) for c in uart_buf)}")
        bin_base_name = args.path.as_posix().split('/')[-1].split('.')[0]
        uart_output_file = f"uart_out_{bin_base_name}.bin"
        print(f"[*] Saving UART output to {uart_output_file}")
        with open(uart_output_file, "wb") as f:
            f.write(bytearray(uart_buf))
    else:
        print("[*] No UART data received")
    print("[*] LoRa Results:")
    for key, value in result["lora_results"].items():
        print(f"  {key}: {value}")


if __name__ == "__main__":
    main()
