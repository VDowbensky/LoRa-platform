#!/usr/bin/env python3
import argparse
import struct

from capstone import *
from unicorn import *
from unicorn.arm_const import *

from emulator_utils import verified_func_bytes, find_bytes_address, get_block_by_addr, _write_mmio_value, _read_u32, \
    _read_vectors, round_up
from uart_device import UartDevice
from lora_device import LoRaCDevice
from gpio import GpioBus

DUMP_BASE = 0x08000000
FLASH_MAX = 128 * 1024
RAM_BASE, RAM_SIZE = 0x20000000, 32 * 1024

SCB_VTOR = 0xE000ED08  # Vector Table Offset Register

READY32 = 0xFFFFFFFF
READY_LPTIM = 0x80
LPTIM0_CR = 0x4000D000

RCC_BASE = 0x40000000  # APB0
EFC_BASE = 0x40020000  # AHB0

UART0_BASE = 0x40003000  # APB0: UART0

config = {
    "debug": False,
    "asm": False,
}
# ---- pending manual-ISR context ----

CALLER_SAVED = [
    UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3,
    UC_ARM_REG_R12, UC_ARM_REG_LR, UC_ARM_REG_XPSR
]


def hook_mem_invalid(uc, access, addr, size, val, _):
    action = {UC_MEM_READ: "READ", UC_MEM_WRITE: "WRITE"}.get(access, access)
    print(f"[!] Invalid memory {action} at 0x{addr:X}, size={size}")
    return False


def hook_mem_read_unmapped(uc, access, addr, size, value, _):
    print(f"[!] Unmapped memory read at 0x{addr:X}, size={size}")
    return False


def load_bin(uc, path: str, app_off: int):
    with open(path, "rb") as f:
        data = f.read()
    size = len(data)
    if size > FLASH_MAX:
        raise ValueError("Binary too large for configured flash max")

    uc.mem_map(DUMP_BASE, round_up(size, 0x1000))
    uc.mem_write(DUMP_BASE, data)

    # Map RAM
    uc.mem_map(RAM_BASE, RAM_SIZE)

    boot_vec = _read_vectors(data, app_off)  # at 0x08004000
    app_base = DUMP_BASE + app_off if app_off >= 0 else DUMP_BASE

    sp, pc = boot_vec

    return pc, sp, size, app_base


def run_emulation(path, debug_functions=False, load_offset=0x4000, count=30000, gpio_pins=None):
    uc = Uc(UC_ARCH_ARM, UC_MODE_THUMB)
    cs = Cs(CS_ARCH_ARM, CS_MODE_THUMB)
    cs.detail = True

    # Map core/peripheral regions
    uc.mem_map(0xE0000000, 0x10000)  # PPB (DWT, etc.)
    uc.mem_map(0x40000000, 0x10000)  # APB0 SFR  (0x4000_0000–0x4000_FFFF)
    uc.mem_map(0x40010000, 0x10000)  # APB1 SFR  (0x4001_0000–0x4001_FFFF)
    uc.mem_map(0x40020000, 0x10000)  # AHB0 SFR  (EFC, QSPI, CRC, DMAC0/1)
    uc.mem_map(0x40030000, 0x10000)  # AHB1 SFR  (RNGC, SAC)

    pc, sp, fsize, app_base = load_bin(uc, path, load_offset)

    pending_isr = {"active": False, "ret": None, "saved": None}

    def call_systick_handler_like_fn(uc):
        if pending_isr["active"]:
            return False  # don't nest

        vtor = _read_u32(uc, SCB_VTOR)
        vec_ent = _read_u32(uc, vtor + 0x3C)
        if vec_ent in (0, 0xFFFFFFFF):
            print("[SysTick] No handler in vector table")
            return False

        handler = vec_ent | 1  # Thumb
        ret = uc.reg_read(UC_ARM_REG_PC)  # where to resume

        # save caller-saved regs (what hardware would restore on exception return)
        saved = {reg: uc.reg_read(reg) for reg in CALLER_SAVED}

        # jump "like BL" and remember to restore when we get back
        uc.reg_write(UC_ARM_REG_LR, ret | 1)
        uc.reg_write(UC_ARM_REG_PC, handler)

        pending_isr["active"] = True
        pending_isr["ret"] = ret & ~1  # unicorn will show even PC in traces
        pending_isr["saved"] = saved

        dprint(f"[SysTick] VTOR=0x{vtor:08X} entry+0x3C=0x{vec_ent:08X} -> handler=0x{handler:08X}")
        return True

    def dprint(*args, **kwargs):
        print(*args, **kwargs) if config.get("debug") else None

    reverse_functions_map = {}
    functions_map = {}

    cycle_counter = {"value": 0}

    def hook_code_increment_cyccnt(uc, address, size, _):
        # if we just returned from our manual ISR, restore caller-saved regs
        if pending_isr["active"] and (address == pending_isr["ret"]):
            for reg, val in pending_isr["saved"].items():
                uc.reg_write(reg, val)
            pending_isr["active"] = False
            pending_isr["ret"] = None
            pending_isr["saved"] = None
            # fall through

        cycle_counter["value"] += 1
        if (cycle_counter["value"] & 0xF) == 0:
            call_systick_handler_like_fn(uc)

    ready_after_reads = {LPTIM0_CR: 4}  # become ready after 4 polls

    periph = {
        0x40000028: 0x0000003F,  # RCC_CR1: set low 6 bits so the poll passes
        0x4000002C: 0x00000000,  # RCC_SR1: all *_CLK_EN_SYNC bits read as 0 -> poll passes
        0x4001D00C: 0x0000000F,  # IWDG_SR (APB1) - all ready bits set so poll succeeds
        LPTIM0_CR: 0x00000118,  # start “not ready”
    }

    uart_buffer = []

    def tx_sink(b):
        uart_buffer.append(b)  # you already print this at the end

    uart0 = UartDevice(UART0_BASE, tx_cb=tx_sink, dprint=dprint)

    lora_cmds = []

    def lora_sink(data):
        lora_cmds.append(data)

    lora_results = {}

    def lora_result(key, val):
        if key in lora_results:
            dprint(f"[LoRa] Overwriting result for {key}: {lora_results[key]} -> {val}")
        lora_results[key] = val
        dprint(f"[LoRa] Result for {key}: {val}")

    gpio = GpioBus(dprint=dprint)

    lora = LoRaCDevice(dprint=dprint, cmd_cb=lora_sink, result_cb=lora_result)

    devices = [uart0, lora, gpio]

    def write_hook(uc, access, addr, size, value, _):
        for dev in devices:
            if dev.handles(addr):
                return dev.write(uc, addr, size, value)

        if addr in periph:
            periph[addr] = value & ((1 << (size * 8)) - 1)
            return True

        # store last-written value so later reads see it
        if (RCC_BASE <= addr < RCC_BASE + 0x1000) or (EFC_BASE <= addr < EFC_BASE + 0x1000) or addr in periph:
            periph[addr] = value & ((1 << (size * 8)) - 1)
            return True

        return False  # allow other writes

    def read_hook(uc, access, addr, size, value, _):
        # delegate to devices
        for dev in devices:
            if dev.handles(addr):
                val = dev.read(uc, addr, size)
                _write_mmio_value(uc, addr, size, val)
                blk = get_block_by_addr(addr)
                dprint(f"[HOOK] {blk} read 0x{addr:X} -> 0x{val:08X}")
                return True, val

        # LPTIM0 “eventually ready” model
        if addr == LPTIM0_CR:
            cnt = ready_after_reads.get(addr, 0)
            val = periph.get(addr, 0)
            if cnt > 0:
                ready_after_reads[addr] = cnt - 1
                val &= ~READY_LPTIM
            else:
                val |= READY_LPTIM
                periph[addr] = val
            _write_mmio_value(uc, addr, size, val)
            dprint(f"[HOOK] LPTIM0 read 0x{addr:X} -> 0x{val:08X} (cnt={cnt})")
            return True, val

        if addr in periph:
            val = periph[addr]
            _write_mmio_value(uc, addr, size, val)
            blk = get_block_by_addr(addr)
            dprint(f"[HOOK] {blk} read 0x{addr:X} -> 0x{val:08X}")
            return True, val

        # Generic “make polls pass” for RCC/EFC
        if (RCC_BASE <= addr < RCC_BASE + 0x1000) or (EFC_BASE <= addr < EFC_BASE + 0x1000):
            # treat as ready/enabled
            _write_mmio_value(uc, addr, 4, READY32)
            dprint(f"[HOOK] RCC/EFC default-ready at 0x{addr:X}")
            return True, READY32

        dprint(f"[HOOK] read_hook at 0x{addr:X}, size={size}, value={value:#x}")
        return False, 0

    def hook_code(uc, addr, size, cs):
        dprint(f"[*] Exec 0x{addr:X}, size {size}")
        # dprint(f"Raw instruction: {uc.mem_read(addr, size).hex()}")

        name = reverse_functions_map.get(addr)
        if name:
            print(f"[*] Call fn {name} call at 0x{addr:X}, size {size}")

        if config.get('asm'):
            for insn in cs.disasm(uc.mem_read(addr, size), addr):
                dprint(f"0x{insn.address:X}:\t{insn.mnemonic}\t{insn.op_str}")

    # Core regs
    uc.reg_write(UC_ARM_REG_SP, sp)
    uc.reg_write(UC_ARM_REG_PC, pc | 1)

    # Point VTOR at our app’s vector table base
    uc.mem_write(SCB_VTOR, struct.pack("<I", app_base))

    uc.hook_add(UC_HOOK_MEM_INVALID, hook_mem_invalid)
    uc.hook_add(UC_HOOK_CODE, hook_code, user_data=cs)
    uc.hook_add(UC_HOOK_MEM_READ, read_hook)
    uc.hook_add(UC_HOOK_BLOCK, hook_code_increment_cyccnt)
    uc.hook_add(UC_HOOK_MEM_WRITE, write_hook)
    uc.hook_add(UC_HOOK_MEM_UNMAPPED, hook_mem_read_unmapped)

    if debug_functions:
        for name, bytes in verified_func_bytes.items():
            addr = find_bytes_address(uc, bytes, from_addr=DUMP_BASE, to_addr=DUMP_BASE + FLASH_MAX)
            if addr is not None:
                functions_map[name] = addr
                dprint(f"[*] Found {name} at 0x{addr:X}")
                reverse_functions_map[addr] = name
            else:
                print(f"[*] {name} not found")
                exit(1)

    # On ASR6601, the region 0x40020000–0x40020FFF is the EFC (embedded flash controller) in the AHB0 SFR block, i.e. you’re polling an EFC status register.
    uc.mem_write(0x40020008, struct.pack("<I", 0x2))

    if gpio_pins:
        for pin, value in gpio_pins.items():
            gpio.by_name["A"].set_input(pin, value)

    error = None
    dprint(f"Initial PC = 0x{pc:X}, SP = 0x{sp:X}")
    try:
        uc.emu_start(pc | 1, app_base + FLASH_MAX, count=count)
    except UcError as e:
        print(f"Unicorn error: {e}")
        error = str(e)
    return {
        "lora_results": lora_results,
        "uart_buffer": uart_buffer,
        "lora_cmds": lora_cmds,
        "emulation_cycle_count": cycle_counter["value"],
        "emulation_error": error
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run a binary on Unicorn emulator with UART and LoRa devices")
    parser.add_argument("bin_path", help="Path to the binary file to run")
    parser.add_argument("--debug", action="store_true", help="Enable debug output")
    parser.add_argument("--asm", action="store_true", help="Print disassembled instructions")
    parser.add_argument("--debug-functions", action="store_true", help="Enable debug for function addresses")
    parser.add_argument("--load-offset", type=int, default=0x4000)
    parser.add_argument("--count", type=int, default=30000, help="Number of instructions to execute")
    parser.add_argument("--gpio15", action="store_true", help="Enable the GPIO 15 mode")
    parser.add_argument("--save-uart", action="store_true", help="Save UART output to a binary file")
    args = parser.parse_args()
    config["debug"] = args.debug
    config["asm"] = args.asm

    gpio = None
    if args.gpio15:
        print("[*] Enabling GPIO 15 mode")
        gpio = {15: 1}

    result = run_emulation(
        args.bin_path, debug_functions=args.debug_functions, load_offset=args.load_offset, count=args.count,
        gpio_pins=gpio
    )

    print("[*] Emulation finished")
    print(f"[*] Cycle count: {result['emulation_cycle_count']}")
    uart_buf = result.get('uart_buffer')
    if uart_buf:
        print(f"[*] UART buffer (length={len(uart_buf)}): {''.join(chr(c) for c in uart_buf)}")
        if args.save_uart:
            bin_base_name = args.bin_path.split('/')[-1].split('.')[0]
            uart_output_file = f"uart_out_{bin_base_name}.bin"
            print(f"[*] Saving UART output to {uart_output_file}")
            with open(uart_output_file, "wb") as f:
                f.write(bytearray(uart_buf))
    else:
        print("[*] No UART data received")

    if result['lora_cmds']:
        print("[*] LoRa commands received:")
        for cmd in result['lora_cmds']:
            print(f"[LoRa] Received command: {cmd}")

    print('-----')
    for key, val in result['lora_results'].items():
        print(f"[LoRa] Result for {key}: {val}")
