#!/usr/bin/env python3
import argparse
import csv
import json
import os.path
from pathlib import Path

from fhss import generate_fhss_frequencies
from parse_config import read_config
from emulate import emulate
from versions import get_checksums, get_versions
from encryption_keys import encryption_keys

try:
    from rich import print as pprint
    from rich.table import Table
    from rich.console import Console
except Exception:
    def pprint(*args, **kwargs):
        print(*args, **kwargs)


    Table = None
    Console = None

try:
    from tabulate import tabulate
except Exception:
    tabulate = None

DUMPS_FOLDER = "dumps"
DUMP_SIZE = 0x20000


def analyze_firmware_dump(firmware_binary_data, filename: Path) -> dict:
    size = len(firmware_binary_data)
    if size < DUMP_SIZE:
        raise ValueError(f"Dump file '{filename}' is too small ({size} bytes), expected at least {DUMP_SIZE} bytes.")
    checksums = get_checksums(firmware_binary_data)
    return {
        "size": len(firmware_binary_data),
        "checksum": checksums,
        "version": get_versions(checksums)
    }


def analyze_dump(filename: Path, run_emu: bool) -> dict:
    filename_as_posix = filename.as_posix()
    firmware_binary_data = filename.read_bytes()
    result = analyze_firmware_dump(firmware_binary_data, filename)
    result_config = read_config(filename_as_posix)

    if run_emu:
        print('Running emulation for', filename_as_posix)
        emulation_result = emulate(firmware_binary_data, bind=False)
        result["emulation"] = emulation_result.get("lora_results")

    return {
        **result,
        "filename": filename_as_posix,
        "config": result_config,
        "notes": encryption_keys.get(result_config.get("encryption_key_hex"), ""),
    }


def parse_filepath(filepath: Path) -> tuple:
    # return tuple for sorting
    # folder name as date in a format dd_mm_yyyy
    date_parts = filepath.parent.name.split("_")
    if len(date_parts) == 3:
        try:
            day = int(date_parts[0])
            month = int(date_parts[1])
            year = int(date_parts[2])
            return year, month, day, filepath.name
        except ValueError:
            pass
    return 0, 0, 0, filepath.name


def analyze_dumps(dumps_folder: str = DUMPS_FOLDER, run_emu: bool = False) -> list:
    dumps_path = Path(dumps_folder)
    if not dumps_path.exists() or not dumps_path.is_dir():
        raise FileNotFoundError(f"The specified dumps folder '{dumps_folder}' does not exist or is not a directory.")

    results = []
    files = dumps_path.glob("*/*.bin")

    for filename in sorted(files, key=parse_filepath):
        if filename.is_file():
            results.append(analyze_dump(filename, run_emu))
    return results


def print_config(config, all_fhss: bool = False):
    pprint(' - encryption_key_hex:', config.get("encryption_key_hex"))
    pprint(' - central_frequency:', config.get("central_frequency") / 1e6, "Mhz")
    pprint(' - channel_width:', config.get("channel_width") / 1e3, "kHz")
    pprint(' - channels_count:', config.get("channels_count"))
    print(' - sync_channels: ', end='')
    pprint(config.get("sync_channels"), sep=' ')
    fhss_freqs = generate_fhss_frequencies(
        config.get("central_frequency", 0),
        config.get("channel_width", 0),
        config.get("channels_count", 0)
    )
    print(' - FHSS:')
    pprint('  - min:', fhss_freqs[0] / 1e6, "MHz")
    pprint('  - max:', fhss_freqs[-1] / 1e6, "MHz")
    if all_fhss:
        print('  - all:', fhss_freqs)


# ---------- Report helpers ----------

def flatten_result(idx, result: dict) -> dict:
    cfg = result.get("config", {}) or {}
    cf_hz = cfg.get("central_frequency") or 0
    cw_hz = cfg.get("channel_width") or 0
    cnt = cfg.get("channels_count") or 0
    fhss_min_mhz = fhss_max_mhz = None
    if cf_hz and cw_hz and cnt:
        fhss = generate_fhss_frequencies(cf_hz, cw_hz, cnt)
        fhss_min_mhz = fhss[0] / 1e6
        fhss_max_mhz = fhss[-1] / 1e6

    emu = result.get("emulation") or {}
    # Normalize numbers to human-friendly units
    path_parts = os.path.normpath(result.get("filename")).split(os.sep)
    short_filename = os.path.join(*path_parts[-2:])
    row = {
        "#": idx + 1,
        "filename": short_filename,
        # "size_bytes": result.get("size"),
        "encryption key": cfg.get("encryption_key_hex"),
        "bootloader": result.get("version", {}).get("bootloader"),
        "firmware": result.get("version", {}).get("firmware"),
        "central MHz": cf_hz / 1e6 if cf_hz else None,
        "channel step kHz": cw_hz / 1e3 if cw_hz else None,
        "channel count": cnt or None,
        "sync channels": ', '.join([str(c) for c in cfg.get("sync_channels")]),
        "fhss min MHz": fhss_min_mhz,
        "fhss max MHz": fhss_max_mhz,
        "emu freq MHz": (emu.get("freq") if emu.get("freq") is None
                         else float(emu.get("freq"))),
        "SF": emu.get("sf"),
        "BW": parse_bw_to_khz(emu.get("bw")),
        "CR": emu.get("cr"),
        "header type": emu.get("header_type"),
        "preamble": emu.get("preamble"),
        "payload": emu.get("payload_len"),
        "iq": emu.get("iq")[:2],
        "notes": result.get("notes"),
    }
    return row


def parse_bw_to_khz(bw_val):
    """
    Accept '62.50 kHz' or '125 kHz' or numeric; return float kHz.
    """
    if bw_val is None:
        return None
    if isinstance(bw_val, (int, float)):
        return float(bw_val)  # assume already kHz
    s = str(bw_val).strip().lower().replace("khz", "").strip()
    try:
        return float(s)
    except ValueError:
        return None


def build_report_rows(results: list) -> list:
    return [flatten_result(idx, r) for idx, r in enumerate(results)]


def print_table_rows(rows: list, style: str = "auto"):
    """
    style: "auto" | "rich" | "tabulate" | "plain"
    """
    if not rows:
        print("No results.")
        return

    headers = list(rows[0].keys())
    data = [[r.get(h) for h in headers] for r in rows]

    # Prefer rich -> tabulate -> plain
    if (style in ("auto", "rich")) and Console and Table:
        table = Table(show_header=True, header_style="bold")
        for h in headers:
            table.add_column(h)
        for row in data:
            table.add_row(*[fmt_cell(v) for v in row])
        Console().print(table)
        return

    if (style in ("auto", "tabulate")) and tabulate:
        print(tabulate(data, headers=headers, tablefmt="github"))
        return

    # plain fallback
    col_w = [max(len(str(h)), max(len(str(r[i])) for r in data)) for i, h in enumerate(headers)]
    fmt = "  ".join("{:<" + str(w) + "}" for w in col_w)
    print(fmt.format(*headers))
    print(fmt.format(*["-" * w for w in col_w]))
    for row in data:
        print(fmt.format(*[str(v) for v in row]))


def fmt_cell(v):
    if v is None:
        return "-"
    if isinstance(v, float):
        # Trim trailing zeros for nicer display
        s = f"{v:.6f}".rstrip("0").rstrip(".")
        return s
    return str(v)


def write_report(rows: list, kind: str, out: Path, statistics: dict):
    out.parent.mkdir(parents=True, exist_ok=True)
    if kind == "csv":
        with out.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    elif kind == "tsv":
        with out.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()), delimiter="\t")
            writer.writeheader()
            writer.writerows(rows)
    elif kind == "json":
        out.write_text(json.dumps(rows, ensure_ascii=False, indent=2))
    elif kind == "md":
        stats_lines = ["\n## Statistics"] + ["- {}: {}".format(k, v) for k, v in statistics.items() if v is not None]
        stats_str = "\n".join(stats_lines)

        if tabulate:
            table = tabulate([[r[k] for k in rows[0].keys()] for r in rows],
                             headers=list(rows[0].keys()), tablefmt="github")
            out.write_text(table + stats_str)
        else:
            hdrs = list(rows[0].keys())
            lines = ["| " + " | ".join(hdrs) + " |",
                     "| " + " | ".join("---" for _ in hdrs) + " |"]
            for r in rows:
                lines.append("| " + " | ".join(str(r[k]) if r[k] is not None else "" for k in hdrs) + " |")
            out.write_text("\n".join(lines) + stats_str)

    else:
        raise ValueError(f"Unknown report kind: {kind}")


def calculate_statistics(rows: list) -> dict:
    """
    Calculate basic statistics from the report rows.
    Returns a dictionary with statistics.
    """
    total_files = len(rows)

    fhss_min = min([r.get("fhss min MHz") for r in rows if r.get("fhss min MHz") is not None])
    fhss_max = max([r.get("fhss max MHz") for r in rows if r.get("fhss max MHz") is not None])
    channel_counts = [r.get("channel count") for r in rows if r.get("channel count") is not None]
    min_channel_count = min(channel_counts) if channel_counts else None
    max_channel_count = max(channel_counts) if channel_counts else None

    return {
        "total_files": total_files,
        "fhss_min_mhz": fhss_min,
        "fhss_max_mhz": fhss_max,
        "min_channel_count": min_channel_count,
        "max_channel_count": max_channel_count,
    }


def main():
    ap = argparse.ArgumentParser(description="Analyze firmware dumps in the specified folder.")
    ap.add_argument("dumps_folder", nargs="?", default=DUMPS_FOLDER, help="Folder containing firmware dumps")
    ap.add_argument("--all-fhss", action="store_true", help="Print all FHSS frequencies (per-file verbose mode)")
    ap.add_argument("--run-emulation", action="store_true", help="Run emulation on the dumps")
    # New reporting options:
    ap.add_argument("--report", choices=["table", "csv", "tsv", "json", "md"],
                    help="Produce a consolidated report. 'table' prints to stdout; others write to --out.")
    ap.add_argument("--out", type=Path, help="Output file path for csv/tsv/json/md reports")
    ap.add_argument("--table-style", choices=["auto", "rich", "tabulate", "plain"], default="auto",
                    help="How to render the table when --report table (default: auto)")
    ap.add_argument("--show-checksum", action="store_true", help="Show checksums in the report")
    ap.add_argument("--plot-fhss-ranges", action="store_true",
                    help="Plot FHSS ranges from the report data (requires matplotlib)")
    ap.add_argument("--plot-fhss-ranges-label", type=str, default=None,
                    help="Column used as label for the FHSS ranges plot bars")
    ap.add_argument("--filter-by-notes", type=str, default=None)

    args = ap.parse_args()

    try:
        dumps_analysis = analyze_dumps(args.dumps_folder, run_emu=args.run_emulation)

        if args.filter_by_notes:
            dumps_analysis = [d for d in dumps_analysis if args.filter_by_notes in d["notes"].lower()]

        if not dumps_analysis:
            print(f"No dumps found in '{args.dumps_folder}' matching the criteria.")
            return

        if not args.report:
            # original per-dump output
            for analysis in dumps_analysis:
                print('#', analysis["filename"])
                print(' - size:', analysis["size"], 'bytes')
                if args.show_checksum:
                    print(' - checksum:')
                    for name, cs in analysis["checksum"].items():
                        print(f'   - {name}: {cs}')
                print(' - version:')
                for name, v in analysis["version"].items():
                    print(f'   - {name}: {v}')

                print("Config:")
                print_config(analysis["config"], args.all_fhss)
                if "emulation" in analysis:
                    print("Emulation Results:")
                    for key, value in analysis["emulation"].items():
                        pprint(f" - {key}: {value}")
                print()
            return

        # consolidated report
        rows = build_report_rows(dumps_analysis)
        statistics = calculate_statistics(rows)
        if args.report == "table":
            print_table_rows(rows, style=args.table_style)
        else:
            if not args.out:
                raise ValueError("--out is required for report types other than 'table'")
            write_report(rows, args.report, args.out, statistics)
            print(f"Report written: {args.out}")

        if args.plot_fhss_ranges:
            from plot import plot_fhss_ranges
            fhss_rows = [(
                r[args.plot_fhss_ranges_label] if args.plot_fhss_ranges_label else "",
                r["channel count"], r["fhss min MHz"], r["fhss max MHz"]) for r in rows]
            fig, ax = plot_fhss_ranges(fhss_rows)
            label = f"_{args.plot_fhss_ranges_label}" if args.plot_fhss_ranges_label else ""
            fig.savefig(f'plot_fhss_ranges{label}.png', dpi=150, bbox_inches="tight")

    except Exception as e:
        print(f"An error occurred while analyzing dumps: {e}")


if __name__ == "__main__":
    main()
