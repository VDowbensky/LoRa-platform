import struct

from unicorn import *
from unicorn.arm_const import *


def safe_mem_read_u32(uc, addr):
    try:
        return int.from_bytes(uc.mem_read(addr, 4), "little")
    except UcError:
        return None


def func_return(uc):
    lr = uc.reg_read(UC_ARM_REG_LR)
    uc.reg_write(UC_ARM_REG_PC, lr | 1)  # Thumb


# UART flags pretty-printer
UART_FLAG_BITS = {
    1 << 7: "TX_FIFO_EMPTY",
    1 << 6: "RX_FIFO_FULL",
    1 << 5: "TX_FIFO_FULL",
    1 << 4: "RX_FIFO_EMPTY",
    1 << 3: "BUSY",
}


def fmt_uart_flags(v):
    return [name for bit, name in UART_FLAG_BITS.items() if v & bit]


def get_block_by_addr(addr):
    if 0x40000000 <= addr <= 0x4000FFFF:
        blk = "APB0"
    elif 0x40010000 <= addr <= 0x4001FFFF:
        blk = "APB1"
    elif 0x40020000 <= addr <= 0x4002FFFF:
        blk = "AHB0"
    elif 0x40030000 <= addr <= 0x4003FFFF:
        blk = "AHB1"
    else:
        blk = "PERIPH"
    return blk


def _read32(uc, addr):
    return struct.unpack("<I", uc.mem_read(addr, 4))[0]


def _write32(uc, addr, val):
    uc.mem_write(addr, struct.pack("<I", val & 0xFFFFFFFF))


def _get_vtor(uc, scb_vtor):
    return struct.unpack("<I", uc.mem_read(scb_vtor, 4))[0]


def _read_u32(uc, addr):
    return struct.unpack("<I", uc.mem_read(addr, 4))[0]


verified_func_bytes = {
    'register_fini': bytes.fromhex('02 4b 13 b1 02 48 00 f0 05 b8'),
    '__libc_init_array': bytes.fromhex('70 b5 0d 4e 0d 4d 76 1b b6 10'),
    'Reset_Handler': bytes.fromhex('00 21 03 e0 0b 4b 5b 58 43 50'),
    'rcc_enable_peripheral_clk': bytes.fromhex('41 28 4a d8 df e8 10 f0 11 02'),
    'rcc_get_uart0_clk_source': bytes.fromhex('4f f0 80 43 98 68 00 f4 c0 30'),
    'rcc_get_clk_freq': bytes.fromhex('4f f0 80 43 01 46 1a 68 02 f4'),
    'uart_get_flag_status': bytes.fromhex('83 69 0b 42 14 bf 01 20 00 20'),
    'uart_cmd': bytes.fromhex('03 6b 19 b1 43 f0 01 03 03 63'),
    'rcc_enable_oscillator': bytes.fromhex('10 b5 0c 46 05 28 0e d8 df e8'),
    'uart_init': bytes.fromhex('03 6b 23 f0 01 03'),
    'gpio_set_iomux': bytes.fromhex(
        '07 29 10 b5 10 d9 0d 4b 08 39 98 42 0b bf 01 eb 41 01 89 00 07 23 0f 23 8b 40 8a 40 c1 6b 21 ea 03 03 1a 43 c2 63 10 bd 83 6b 89 00 0f 24 8c 40 23 ea 04 03 8a 40 1a 43 82 63 f4 e7'),
    'SpiInOut': bytes.fromhex('04 4b 98 60 da 68 02 f0 11 02'),
}


def find_bytes_address(uc, pattern: bytes, from_addr, to_addr):
    """
    Find the first address in memory that matches the given byte pattern.
    """
    for addr in range(from_addr, to_addr, 4):
        try:
            data = uc.mem_read(addr, len(pattern))
            if data == pattern:
                return addr
        except UcError:
            continue
    return None


def _write_mmio_value(uc, addr, size, val):
    if size == 1:
        uc.mem_write(addr, struct.pack("<B", val & 0xFF))
    elif size == 2:
        uc.mem_write(addr, struct.pack("<H", val & 0xFFFF))
    else:
        uc.mem_write(addr, struct.pack("<I", val & 0xFFFFFFFF))


def round_up(x, align): return (x + (align - 1)) & ~(align - 1)


def _read_vectors(blob, off):
    """Return (sp, pc) from a vector table at given offset; None if too short."""
    if off + 8 > len(blob):
        return None
    return struct.unpack_from("<II", blob, off)


def _pc_in_range(pc, start, size):
    return start <= (pc & ~1) < (start + size)
