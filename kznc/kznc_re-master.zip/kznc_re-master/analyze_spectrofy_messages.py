#!/usr/bin/env python3
import json
from pathlib import Path
from collections import defaultdict, Counter


def find_common_groups(folder: str):
    folder = Path(folder)
    data_to_files = defaultdict(set)

    # scan all json files
    for file in folder.glob("*.json"):
        try:
            with file.open("r") as f:
                content = json.load(f)
        except Exception as e:
            print(f"❌ Failed to load {file}: {e}")
            continue

        for msg in content.get("msgs", []):
            data = msg.get("data")
            if data:
                data_to_files[data].add(str(content['id']))

    # now invert: group files by shared data
    groups = []
    seen = set()
    for data, files in data_to_files.items():
        if len(files) > 1:
            key = frozenset(files)
            if key not in seen:
                groups.append((list(files), data))
                seen.add(key)

    return groups


if __name__ == "__main__":
    folder = "spectrofy_data/processed"
    groups = find_common_groups(folder)

    # Print groups
    for files, data in groups:
        print(f"Data {data} is common in: {', '.join(sorted(files))}")

    # Count how many times each file appears in groups
    file_counter = Counter()
    for files, _ in groups:
        file_counter.update(files)

    print("\n📊 Files with most common messages:")
    for file_id, count in file_counter.most_common():
        print(f"{file_id}: {count} common messages")
        if count == 1:
            break
