# LR11XX Tx continuous wave example

## Description

The example will automatically set the device in Tx Continuous-wave mode.

## Configuration

Common parameters can be updated in [`../../common/apps_configuration.h`](../../common/apps_configuration.h) header file, refer to [`../../common/README.md`](../../common/README.md) for more details.

There is no parameter specific to this example.
